<template>
  <div class="error">
    <img src="../../assets/404.png" alt="" />
  </div>
</template>

<script>
export default {};
</script>

<style lang="less" scoped>
.error {
  width: 100%;
  height: 100%;
  img {
    width: 100%;
    height: 100%;
  }
}
</style>