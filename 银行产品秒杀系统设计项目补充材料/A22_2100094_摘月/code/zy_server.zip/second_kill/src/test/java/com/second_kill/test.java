package com.second_kill;

import com.second_kill.service.ILoansGoodService;
import com.second_kill.service.IPreFilterService;
import com.second_kill.utils.Sm4Util;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
@Component
public class test {
    @Autowired
    IPreFilterService preFilterService;
    @Autowired
    ILoansGoodService loansGoodService;

    @Test
    public void main() {
        preFilterService.updateFilterLoans(loansGoodService.getBaseMapper().selectById(21));
    }

}
