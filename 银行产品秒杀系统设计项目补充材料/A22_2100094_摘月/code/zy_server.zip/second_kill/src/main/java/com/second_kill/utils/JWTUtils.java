package com.second_kill.utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTCreator;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.second_kill.service.ex.SystemException;

import java.util.Calendar;
import java.util.Map;
import java.util.Objects;

public class JWTUtils {
    private static final String secretKey = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9";

    /**
     * 生成token
     *
     * @param map //传入payload
     * @return 返回token
     */
    public static String getToken(Map<String, String> map) {
        JWTCreator.Builder builder = JWT.create();
        map.forEach(builder::withClaim);
        Calendar instance = Calendar.getInstance();
        instance.add(Calendar.SECOND, 60 * 60 * 24 * 3);
        builder.withExpiresAt(instance.getTime());
        return builder.sign(Algorithm.HMAC256(secretKey));
    }

    /**
     * 验证token
     *
     * @param token
     * @return
     */
    public static void verify(String token) {
        getDecodedJWT(token);
    }

    /**
     * 从token取json
     *
     * @param token
     * @return
     */
    public static Integer JWTGetUserId(String token) {
        DecodedJWT decodedJWT = getDecodedJWT(token);
        if(decodedJWT.getClaim("admin")!=null){
            if(Objects.equals(decodedJWT.getClaim("admin").asString(), "YES"))
                throw new SystemException("不支持管理员访问");
        }
        return Integer.valueOf(decodedJWT.getClaim("userId").asString());
    }

    public static Integer JWTGetAdminId(String token) {
        return Integer.valueOf(getDecodedJWT(token).getClaim("userId").asString());
    }
    public static Boolean JWTGetIsAdmin(String token){
        DecodedJWT decodedJWT = getDecodedJWT(token);
        Claim isAdmin = decodedJWT.getClaim("admin");
        if(isAdmin == null)return false;
        return Objects.equals(isAdmin.asString(), "YES");
    }
    /**
     * 取解码的jwt对象
     *
     * @param token
     * @return
     */
    private static DecodedJWT getDecodedJWT(String token) {
        return JWT.require(Algorithm.HMAC256(secretKey))
                .build()
                .verify(token);
    }

    /**
     * 获取token中payload
     *
     * @param token
     * @return
     */
    public static DecodedJWT getToken(String token) {
        return JWT.require(Algorithm.HMAC256(secretKey)).build().verify(token);
    }


}