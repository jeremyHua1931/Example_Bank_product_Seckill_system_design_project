package com.second_kill.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@TableName(value = "deposit_favor", autoResultMap = true, excludeProperty = "isLoans")
@NoArgsConstructor
public class DepositFavor extends FavorGood implements Serializable {
    public DepositFavor(Integer userId, Integer goodId, Date dateTime) {
        super(null, userId, goodId, 1, dateTime);
    }
}