package com.second_kill.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.second_kill.entity.LoansFavor;
import com.second_kill.mapper.ILoansFavorMapper;
import com.second_kill.service.ILoansFavorService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ILoansFavorServiceImpl extends ServiceImpl<ILoansFavorMapper, LoansFavor> implements ILoansFavorService {
    @Override
    public List<LoansFavor> getByUGId(Integer goodId, Integer userId) {
        QueryWrapper<LoansFavor> qw = new QueryWrapper<>();
        qw.eq("goodId", goodId);
        qw.eq("userId", userId);
        return this.getBaseMapper().selectList(qw);
    }
}
