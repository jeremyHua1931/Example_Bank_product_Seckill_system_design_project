package com.second_kill.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.second_kill.entity.RuleGroup;

public interface IRuleGroupService extends IService<RuleGroup> {
    void deleteRuleGroup(Integer id);
}
