package com.second_kill.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.second_kill.entity.LoansResult;

import java.util.List;

public interface ILoansResultService extends IService<LoansResult> {
    /**
     * 获取贷款初筛结果
     *
     * @param goodId
     * @param page
     * @param size
     * @return
     */
    List<LoansResult> loansFilterResult(Integer goodId, Integer page, Integer size);
}
