package com.second_kill.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.second_kill.entity.DepositGood;

import java.util.Date;
import java.util.List;

public interface IDepositMapper extends BaseMapper<DepositGood> {
    List<Integer> getIdList();

    void updateRemain(Integer id, Integer remain);
    void updateStatus(Integer id, Integer status);
}
