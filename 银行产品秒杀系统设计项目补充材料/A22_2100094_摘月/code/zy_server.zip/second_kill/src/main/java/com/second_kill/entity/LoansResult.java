package com.second_kill.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName(value="loans_result",autoResultMap = true)
public class LoansResult implements Serializable {
    @TableId(type = IdType.AUTO)
    private Integer id; //结果id
    private Integer userId;
    private Integer goodId;
    private Integer result;
    @TableField(typeHandler = JacksonTypeHandler.class)
    private List<Rule> reason;
    private String reasonStr;
    @TableField(exist = false)
    private String phone;
    private String username;
    private String avatar;
    private Date createTime;
}
