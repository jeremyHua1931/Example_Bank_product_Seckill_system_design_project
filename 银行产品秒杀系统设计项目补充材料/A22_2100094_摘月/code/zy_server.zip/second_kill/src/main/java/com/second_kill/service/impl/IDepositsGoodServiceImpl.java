package com.second_kill.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.second_kill.entity.*;
import com.second_kill.mapper.IDepositMapper;
import com.second_kill.mapper.IDepositOrderMapper;
import com.second_kill.service.IDepositsGoodService;
import com.second_kill.utils.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;


@Service
public class IDepositsGoodServiceImpl extends ServiceImpl<IDepositMapper, DepositGood> implements IDepositsGoodService {
    @Autowired
    IDepositOrderMapper depositOrderMapper;

    @Override
    public PagesBean search(GoodSearch goodSearch) {
        QueryWrapper<DepositGood> qw = new QueryWrapper<>();
        if (!StringUtil.isBlank(goodSearch.getName())) {
            qw.like("name", goodSearch.getName());
        }
        if (goodSearch.getMinPrice() != null) {
            qw.ge("min_price", goodSearch.getMinPrice());
        }
        if (goodSearch.getMaxPrice() != null) {
            qw.le("max_price", goodSearch.getMaxPrice());
        }
        if (goodSearch.getStartTime() != null) {
            qw.ge("start_time", goodSearch.getStartTime());
        }
        if (goodSearch.getEndTime() != null) {
            qw.ge("end_time", goodSearch.getEndTime());
        }
        if (goodSearch.getStatus() != null) {
            Date currentTime = new Date();
            switch (goodSearch.getStatus()) {
                case 0:
                    qw.gt("start_time", currentTime);
                    //qw.eq("status", 0);
                    break;
                case 2:
                    qw.lt("end_time", currentTime);
                    qw.eq("status", 2);
                    break;
                case 1:
                    qw.le("start_time", currentTime);
                    qw.ge("end_time", currentTime);
 //                   qw.eq("status", 1);
                    break;
            }
        }
        qw.func(i -> {
            if (goodSearch.getSort() != null) {
                if (goodSearch.getSort()) {
                    i.orderByDesc("price");
                } else {
                    i.orderByAsc("price");
                }
            }
        });
        IPage<DepositGood> page = new Page<>(goodSearch.getPage(), goodSearch.getSize());
        page = this.getBaseMapper().selectPage(page, qw);
        return new PagesBean(page.getTotal(), page.getRecords());
    }

    @Override
    public PagesBean getDepositListById(OrderFactor orderFactor) {
        orderFactor.setPage(orderFactor.getPage() - 1);
        List<DepositOrder> list = depositOrderMapper.getDepositOrder(orderFactor);
        Long count = (long) list.size();
        return new PagesBean(count, list);
    }

    /**
     * 根据条件返回所有存款订单信息
     *
     * @param orderFactor
     * @return
     */
    @Override
    public PagesBean getAllOrder(AllOrderFactor orderFactor) {
        List<DepositOrder> list = depositOrderMapper.getAllOrder(orderFactor);
        System.out.println(list);
        Long count = Long.valueOf(depositOrderMapper.getOrderNumber(orderFactor));
        return new PagesBean(count, list);
    }
}
