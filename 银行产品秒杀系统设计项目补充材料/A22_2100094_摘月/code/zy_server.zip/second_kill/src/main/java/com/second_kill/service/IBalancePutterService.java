package com.second_kill.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import redis.clients.jedis.Jedis;

public interface IBalancePutterService {
    void redis_hset(Integer userId, Double changeVal);

    @Async
    @Scheduled(fixedRate = 1000)
    void putVal();

    double getUncosted(Integer userId);

    Integer preCostBalance(Integer userId, Double changeVal, Jedis jedis);
}
