package com.second_kill.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.second_kill.entity.DepositResult;
import com.second_kill.mapper.IDepositResultMapper;
import com.second_kill.service.IDepositResultService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IDepositResultServiceImpl extends ServiceImpl<IDepositResultMapper, DepositResult> implements IDepositResultService {

    @Autowired
    IDepositResultMapper depositResultMapper;

    /**
     * 获取存款初筛结果
     *
     * @param goodId 货物id
     * @param page   第几页
     * @param size   一页有几条
     * @return
     */
    @Override
    public List<DepositResult> depositFilterResult(Integer goodId, Integer page, Integer size) {
        page = page - 1; //limit分页默认从page = 0开始查询，所以要-1。
        return depositResultMapper.depositFilterResult(goodId, page, size);
    }

}
