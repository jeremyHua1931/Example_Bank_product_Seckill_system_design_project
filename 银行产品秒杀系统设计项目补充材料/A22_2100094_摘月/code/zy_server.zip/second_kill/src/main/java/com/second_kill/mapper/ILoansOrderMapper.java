package com.second_kill.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.second_kill.entity.AllOrderFactor;
import com.second_kill.entity.ClientOrder;
import com.second_kill.entity.LoansOrder;
import com.second_kill.entity.OrderFactor;

import java.util.List;

public interface ILoansOrderMapper extends BaseMapper<LoansOrder> {
    List<LoansOrder> getLoansOrder(OrderFactor orderFactor);

    List<LoansOrder> getAllOrder(AllOrderFactor orderFactor);

    Integer getMaxOrderId();

    List<LoansOrder> getClientOrder(ClientOrder order);

    Integer getOrderNumber(AllOrderFactor orderFactor);
}
