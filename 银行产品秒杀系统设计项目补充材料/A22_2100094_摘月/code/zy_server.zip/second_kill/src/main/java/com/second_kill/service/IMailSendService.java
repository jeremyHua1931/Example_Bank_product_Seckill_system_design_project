package com.second_kill.service;

public interface IMailSendService {
    void sendMail(String sendTo, String subject,String mailTitle, String text);

    void sendToAdmin(String subject,String mailTitle, String text);
}
