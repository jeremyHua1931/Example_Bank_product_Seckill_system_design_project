package com.second_kill.controller;


import com.alibaba.fastjson.JSONObject;
import com.second_kill.config.RedisPrefix;
import com.second_kill.controller.exhandler.BaseController;
import com.second_kill.entity.DepositGood;
import com.second_kill.entity.LoansGood;
import com.second_kill.entity.ResponseBean;
import com.second_kill.entity.dashboard.*;
import com.second_kill.service.IDepositsGoodService;
import com.second_kill.service.ILoansGoodService;
import com.second_kill.utils.JedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.Tuple;

import java.text.DecimalFormat;
import java.util.*;

@RestController
@RequestMapping("/admin/dashboard")
public class DashboardController extends BaseController {


    private final ILoansGoodService iLoansGoodService;
    private final IDepositsGoodService iDepositsGoodService;

    @Autowired
    DashboardController(ILoansGoodService iLoansGoodService, IDepositsGoodService iDepositsGoodService) {
        this.iLoansGoodService = iLoansGoodService;
        this.iDepositsGoodService = iDepositsGoodService;
    }

    @GetMapping("/user")
    public JSONObject user() {
        Jedis jedis = JedisUtil.getJedis();
        assert jedis != null;
        //取得对象
        Map<String, String> visits = jedis.hgetAll(RedisPrefix.VISITS);
        Map<String, String> newUser = jedis.hgetAll(RedisPrefix.NEW_USER);

        //取得key
        Set<String> visitsKeys = visits.keySet();
        Set<String> newUserKeys = newUser.keySet();

        //转为List，方便按日期排序
        List<String> visitsKeyList = new ArrayList<>(visitsKeys);
        List<String> newUserKeyList = new ArrayList<>(newUserKeys);

        //按照日期降序排序
        visitsKeyList.sort(Collections.reverseOrder());
        newUserKeyList.sort(Collections.reverseOrder());

        List<VisitChart> visitChartList = new ArrayList<>();
        for (String visitsKey : visitsKeyList
        ) {
            VisitChart visitChart = new VisitChart();
            visitChart.setDate(visitsKey);
            visitChart.setNumber(Integer.parseInt(visits.get(visitsKey)));
            visitChartList.add(visitChart);
        }

        List<Integer> newUserNumberList = new ArrayList<>();
        for (String newUserKey : newUserKeyList
        ) {
            newUserNumberList.add(Integer.parseInt(newUser.get(newUserKey)));
        }

        int visitsSize = visitChartList.size();
        int newUserSize = newUserNumberList.size();

        int visitsDay = 0, newUserDay = 0;
        if (visitsSize > 0)
            visitsDay = visitChartList.get(0).getNumber();
        if (newUserSize > 0)
            newUserDay = newUserNumberList.get(0);

        int visitsLastDay = 0, newUserLastDay = 0;
        if (visitsSize > 1)
            visitsLastDay = visitChartList.get(1).getNumber();
        if (newUserSize > 1)
            newUserLastDay = newUserNumberList.get(1);

        int visitsWeek = visitsDay;
        int newUserWeek = newUserDay;

        int visitsLastWeek = 0, newUserLastWeek = 0;
        if (visitsSize > 7)
            visitsLastWeek = visitChartList.get(7).getNumber();
        if (newUserSize > 7)
            newUserLastWeek = newUserNumberList.get(7);

        int visitsMonth = 0;
        int newUserMonth = 0;

        for (int i = 1; i < 7; i++) {
            if (visitsSize > i)
                visitsWeek += visitChartList.get(i).getNumber();
            if (visitsSize > (i + 7))
                visitsLastWeek += visitChartList.get(i + 7).getNumber();

            if (newUserSize > i)
                newUserWeek += newUserNumberList.get(i);
            if (newUserSize > (i + 7))
                newUserLastWeek += newUserNumberList.get(i + 7);

            if (visitsSize > (i + 14))
                visitsMonth += visitChartList.get(i + 14).getNumber();
            if (newUserSize > (i + 14))
                newUserMonth += newUserNumberList.get(i + 14);
        }

        for (int i = 21; i < 31; i++) {
            if (visitsSize > i)
                visitsMonth += visitChartList.get(i).getNumber();
            if (newUserSize > i)
                newUserMonth += newUserNumberList.get(i);
        }

        visitsMonth += visitsWeek + visitsLastWeek;
        newUserMonth += newUserWeek + newUserLastWeek;


        DecimalFormat df = new DecimalFormat("0.00");

        DashBoardUser dashBoardUser = new DashBoardUser();
        dashBoardUser.setVisitsDay(visitsDay);
        dashBoardUser.setNewUserDay(newUserDay);

        dashBoardUser.setVisitsDayOnDay(df.format((visitsDay + 0.0) / visitsLastDay));
        dashBoardUser.setNewUserDayOnDay(df.format((newUserDay + 0.0) / newUserLastDay));

        dashBoardUser.setVisitsWeekOnWeek(df.format((visitsWeek + 0.0) / visitsLastWeek));
        dashBoardUser.setNewUserWeekOnWeek(df.format((newUserWeek + 0.0) / newUserLastWeek));

        dashBoardUser.setVisitsMonth(visitsMonth);
        dashBoardUser.setNewUserMonth(newUserMonth);

        Collections.reverse(visitChartList);
        dashBoardUser.setVisitChart(visitChartList);



//        return new ResponseBean(200, "查询成功", dashBoardUser);
        return JSONObject.parseObject("{    \"code\": 200,    \"msg\": \"eiusmod velit nisi elit aliqua\",    \"data\": {      \"visitsDay\": 73,      \"visitsMonth\": 689,      \"visitsDayOnDay\": 19.52,      \"visitsWeekOnWeek\": 17.4,      \"newUserDay\": 96,      \"newUserMonth\": 904,      \"newUserWeekOnWeek\": 1.82,      \"newUserDayOnDay\": 8.125,      \"visitChart\": [        {          \"number\": 94,          \"date\": \"03-01\"        },        {          \"number\": 62,          \"date\": \"03-02\"        },        {          \"number\": 68,          \"date\": \"03-03\"        },        {          \"number\": 87,          \"date\": \"03-04\"        },        {          \"number\": 65,          \"date\": \"03-05\"        },        {          \"number\": 96,          \"date\": \"03-06\"        },        {          \"number\": 74,          \"date\": \"03-07\"        },        {          \"number\": 82,          \"date\": \"03-08\"        },        {          \"number\": 66,          \"date\": \"03-09\"        },        {          \"number\": 99,          \"date\": \"03-10\"        },        {          \"number\": 69,          \"date\": \"03-11\"        },        {          \"number\": 91,          \"date\": \"03-12\"        },        {          \"number\": 68,          \"date\": \"03-13\"        },        {          \"number\": 75,          \"date\": \"03-14\"        },        {          \"number\": 91,          \"date\": \"03-15\"        },        {          \"number\": 89,          \"date\": \"03-16\"        },        {          \"number\": 61,          \"date\": \"03-17\"        },        {          \"number\": 96,          \"date\": \"03-18\"        },        {          \"number\": 61,          \"date\": \"03-19\"        },        {          \"number\": 97,          \"date\": \"03-20\"        },        {          \"number\": 92,          \"date\": \"03-21\"        },        {          \"number\": 71,          \"date\": \"03-22\"        },        {          \"number\": 92,          \"date\": \"03-23\"        },        {          \"number\": 86,          \"date\": \"03-24\"        },        {          \"number\": 97,          \"date\": \"03-25\"        },        {          \"number\": 66,          \"date\": \"03-26\"        },        {          \"number\": 68,          \"date\": \"03-27\"        },        {          \"number\": 80,          \"date\": \"03-28\"        },        {          \"number\": 99,          \"date\": \"03-29\"        }      ]    }  }");
    }


    @GetMapping("/sale")
    public JSONObject sale() {
/*        Jedis jedis = JedisUtil.getJedis();
        assert jedis != null;
        //取得对象
        Map<String, String> amountLoans = jedis.hgetAll(RedisPrefix.AMOUNT_LOANS);
        Map<String, String> amountDeposit = jedis.hgetAll(RedisPrefix.AMOUNT_DEPOSIT);
        Map<String, String> order = jedis.hgetAll(RedisPrefix.ORDER_NUMBER);
        Integer customerTotal = Integer.parseInt(jedis.get(RedisPrefix.TOTAL_USER));
        Integer customerOnceConsumed = Integer.parseInt(jedis.get(RedisPrefix.CUSTOMER_ONCE_CONSUMED));
        Integer customerRegularConsumed = Integer.parseInt(jedis.get(RedisPrefix.CUSTOMER_REGULAR_CONSUMED));


        Set<Tuple> depositOrderSet = jedis.zrevrangeByScoreWithScores(RedisPrefix.ORDER_NUMBER_DEPOSIT, Double.MAX_VALUE, 0
                , 0, 6);
        Set<Tuple> loansOrderSet = jedis.zrevrangeByScoreWithScores(RedisPrefix.ORDER_NUMBER_LOANS, Double.MAX_VALUE, 0
                , 0, 6);

        //取得key
        Set<String> amountKeys;
        if (amountLoans.size() >= amountDeposit.size()) {
            amountKeys = amountLoans.keySet();
        } else {
            amountKeys = amountDeposit.keySet();
        }
        Set<String> orderKeys = order.keySet();

        //转为List，方便按日期排序

        List<String> amountKeyList = new ArrayList<>(amountKeys);
        List<String> orderKeyList = new ArrayList<>(orderKeys);

        //按照日期降序排序
        amountKeyList.sort(Collections.reverseOrder());
        orderKeyList.sort(Collections.reverseOrder());

        List<SaleChart> saleChartList = new ArrayList<>();
        for (String amountKey : amountKeyList
        ) {
            SaleChart saleChart = new SaleChart();
            saleChart.setDate(amountKey);
            saleChart.setDeposit(Double.parseDouble(amountDeposit.getOrDefault(amountKey, "0")));
            saleChart.setLoans(Double.parseDouble(amountLoans.getOrDefault(amountKey, "0")));
            saleChartList.add(saleChart);
        }


        List<Integer> goodIds;
        List<GoodRank> loansRankList = new ArrayList<>();
        if (loansOrderSet.size() > 0) {

            goodIds = new ArrayList<>();

            //获取前六名的id
            for (Tuple element : loansOrderSet) {
                Integer loansId = Integer.parseInt(element.getElement());
                goodIds.add(loansId);
            }
            //获取前六名的信息
            List<LoansGood> loansGoodList = iLoansGoodService.getBaseMapper().selectBatchIds(goodIds);

            int i = 0;
            // 装载
            for (Tuple element : loansOrderSet) {
                GoodRank goodRank = new GoodRank();

                goodRank.setId(loansGoodList.get(i).getId());
                goodRank.setName(loansGoodList.get(i++).getName());
                String number = String.valueOf(element.getScore());
                goodRank.setNumber(Integer.valueOf(number.substring(0, number.indexOf('.'))));
                loansRankList.add(goodRank);
            }
        }


        List<GoodRank> depositRankList = new ArrayList<>();
        if (depositOrderSet.size() > 0) {
            goodIds = new ArrayList<>();

            for (Tuple element : depositOrderSet) {
                Integer depositId = Integer.parseInt(element.getElement());
                goodIds.add(depositId);
            }

            List<DepositGood> depositGoodList = iDepositsGoodService.getBaseMapper().selectBatchIds(goodIds);

            int i = 0;
            for (Tuple element : depositOrderSet) {
                GoodRank goodRank = new GoodRank();

                goodRank.setId(depositGoodList.get(i).getId());
                goodRank.setName(depositGoodList.get(i++).getName());
                String number = String.valueOf(element.getScore());
                goodRank.setNumber(Integer.valueOf(number.substring(0, number.indexOf('.'))));
                depositRankList.add(goodRank);
            }
        }

        //便于之后判断是否超下标
        int saleSize = saleChartList.size();
        int orderSize = orderKeyList.size();

        double amountDay = 0.0, amountLastDay = 0.0;
        if (saleSize > 0)
            amountDay = saleChartList.get(0).getDeposit() + saleChartList.get(0).getLoans();
        if (saleSize > 1)
            amountLastDay = saleChartList.get(1).getDeposit() + saleChartList.get(1).getLoans();

        int orderDay = 0, orderLastDay = 0;
        if (orderSize > 0)
            orderDay = Integer.parseInt(order.get(orderKeyList.get(0)));

        if (orderSize > 1)
            orderLastDay = Integer.parseInt(order.get(orderKeyList.get(1)));

        double amountWeek = amountDay, amountLastWeek = 0;
        if (saleSize > 7)
            amountLastWeek = saleChartList.get(7).getDeposit() + saleChartList.get(7).getLoans();

        int orderWeek = orderDay, orderLastWeek = 0;
        if (orderSize > 7)
            orderLastWeek = Integer.parseInt(order.get(orderKeyList.get(7)));

        double amountMonth = 0.0;
        int orderMonth = 0;

        int i;
        // 累加周、月
        for (i = 1; i < 7; i++) {

            if (saleSize > i)
                amountWeek += saleChartList.get(i).getDeposit() + saleChartList.get(i).getLoans();
            if (saleSize > (i + 7))
                amountLastWeek += saleChartList.get(i + 7).getDeposit() + saleChartList.get(i + 7).getLoans();

            if (orderSize > i)
                orderWeek += Integer.parseInt(order.get(orderKeyList.get(i)));
            if (saleSize > (i + 7))
                orderLastWeek += Integer.parseInt(order.get(orderKeyList.get(i + 7)));

            if (saleSize > (14 + i))
                amountMonth += saleChartList.get(i + 14).getDeposit() + saleChartList.get(14 + i).getLoans();
            if (orderSize > (14 + i))
                orderMonth += Integer.parseInt(order.get(orderKeyList.get(i + 14)));
        }

        for (i = 21; i < 31; i++) {
            if (saleSize > i)
                amountMonth += saleChartList.get(i).getDeposit() + saleChartList.get(i).getLoans();
            if (orderSize > i)
                orderMonth += Integer.parseInt(order.get(orderKeyList.get(i)));
        }

        amountMonth += amountWeek + amountLastWeek;
        orderMonth += orderWeek + orderLastWeek;

        // 客户类型
        List<CustomerChart> customerChartList = new ArrayList<>();

        CustomerChart customerChart = new CustomerChart();
        customerChart.setType("未消费客户");
        customerChart.setNumber(customerTotal - customerOnceConsumed - customerRegularConsumed);
        customerChartList.add(customerChart);

        customerChart = new CustomerChart();
        customerChart.setType("消费一次客户");
        customerChart.setNumber(customerOnceConsumed);
        customerChartList.add(customerChart);

        customerChart = new CustomerChart();
        customerChart.setType("老客户");
        customerChart.setNumber(customerRegularConsumed);
        customerChartList.add(customerChart);


        DecimalFormat df = new DecimalFormat("0.00");

        DashboardSale dashboardSale = new DashboardSale();

        dashboardSale.setAmountDay(df.format(amountDay));
        dashboardSale.setOrderDay(orderDay);

        dashboardSale.setAmountDayOnDay(df.format(amountDay / amountLastDay));
        dashboardSale.setOrderDayOnDay(df.format((orderDay + 0.0) / orderLastDay));

        dashboardSale.setAmountWeekOnWeek(df.format(amountWeek / amountLastWeek));
        dashboardSale.setOrderWeekOnWeek(df.format((orderWeek + 0.0) / orderLastWeek));

        dashboardSale.setAmountMonth(df.format(amountMonth));
        dashboardSale.setOrderMonth(orderMonth);

        dashboardSale.setLoansRank(loansRankList);
        dashboardSale.setDepositRank(depositRankList);

        Collections.reverse(saleChartList);
        dashboardSale.setSaleChart(saleChartList);
        dashboardSale.setCustomerChart(customerChartList);*/

        //return new ResponseBean(200, "查询成功", dashboardSale);
        return JSONObject.parseObject("{  \"code\": 200,  \"msg\": \"reprehenderit nostrud\",  \"data\": {    \"amountDay\": 7000.00,    \"amountMonth\": 59800.99,    \"amountDayOnDay\": 3.7,    \"amountWeekOnWeek\": 6.2,    \"orderDay\": 83,    \"orderMonth\": 920,    \"orderWeekOnWeek\": 8.528,    \"orderDayOnDay\": 13.88,    \"depositRank\": [      {        \"name\": \"汇利存款2022年第73期\",        \"number\": 64,        \"id\": 630000200801105400      },      {        \"name\": \"汇利存款2022年第71期\",        \"number\": 67,        \"id\": 820000200507228400      },      {        \"name\": \"汇利存款2022年第72期\",        \"number\": 60,        \"id\": 310000198907253400      },      {        \"name\": \"汇利存款2022年第74期\",        \"number\": 78,        \"id\": 650000197201054000      },      {        \"name\": \"汇利存款2022年第75期\",        \"number\": 90,        \"id\": 540000199704047200      }    ],    \"customerChart\": [      {        \"number\": 75,        \"type\": \"未消费客户\"      },      {        \"number\": 92,        \"type\": \"未消费客户\"      },      {        \"number\": 75,        \"type\": \"消费一次客户\"      }    ],    \"saleChart\": [      {        \"date\": \"03-02\",        \"deposit\": 8861.444,        \"loans\": 4794.25      },      {        \"date\": \"08-23\",        \"deposit\": 12102.16,        \"loans\": 15119.3      },      {        \"date\": \"02-15\",        \"deposit\": 12107.8,        \"loans\": 4048.66      },      {        \"date\": \"02-06\",        \"deposit\": 4283.8,        \"loans\": 15362.13      },      {        \"date\": \"01-20\",        \"deposit\": 2922.1,        \"loans\": 8604.06      },      {        \"date\": \"06-02\",        \"deposit\": 5291.3,        \"loans\": 2201.62      },      {        \"date\": \"11-26\",        \"deposit\": 6572.27,        \"loans\": 12514.84      },      {        \"date\": \"06-19\",        \"deposit\": 14503.623,        \"loans\": 3404.6      },      {        \"date\": \"03-27\",        \"deposit\": 3703.562,        \"loans\": 11218.52      },      {        \"date\": \"06-16\",        \"deposit\": 1804.9,        \"loans\": 8122.4      },      {        \"date\": \"08-15\",        \"deposit\": 9612.9,        \"loans\": 7083.87      },      {        \"date\": \"09-05\",        \"deposit\": 2770.25,        \"loans\": 6243.8      },      {        \"date\": \"08-05\",        \"deposit\": 2743.893,        \"loans\": 2754.477      },      {        \"date\": \"10-05\",        \"deposit\": 19261.654,        \"loans\": 17868.4      },      {        \"date\": \"04-03\",        \"deposit\": 12184.793,        \"loans\": 13530.224      },      {        \"date\": \"11-08\",        \"deposit\": 12447.1,        \"loans\": 8254.7      },      {        \"date\": \"04-12\",        \"deposit\": 15479.3,        \"loans\": 11611.354      },      {        \"date\": \"01-22\",        \"deposit\": 9271.6,        \"loans\": 1162.76      },      {        \"date\": \"12-03\",        \"deposit\": 7277.83,        \"loans\": 2506.4      },      {        \"date\": \"06-02\",        \"deposit\": 12687.55,        \"loans\": 11910.9      },      {        \"date\": \"11-10\",        \"deposit\": 16912.4,        \"loans\": 12122.282      },      {        \"date\": \"05-08\",        \"deposit\": 15237.01,        \"loans\": 5361.3      },      {        \"date\": \"04-05\",        \"deposit\": 16602.48,        \"loans\": 15454.5      },      {        \"date\": \"03-02\",        \"deposit\": 3614.03,        \"loans\": 9887.22      },      {        \"date\": \"06-13\",        \"deposit\": 2387.527,        \"loans\": 17762.22      },      {        \"date\": \"03-19\",        \"deposit\": 18722.45,        \"loans\": 10258.68      },      {        \"date\": \"04-10\",        \"deposit\": 11612.28,        \"loans\": 19877.774      },      {        \"date\": \"12-07\",        \"deposit\": 19068.882,        \"loans\": 8091.34      },      {        \"date\": \"12-30\",        \"deposit\": 19114.29,        \"loans\": 3676.2      }    ],    \"loansRank\": [      {        \"name\": \"代百花步速\",        \"number\": 60,        \"id\": 110000199006149500      },      {        \"name\": \"片没说不支\",        \"number\": 85,        \"id\": 460000199004274400      },      {        \"name\": \"门当治南斯运\",        \"number\": 61,        \"id\": 640000200912184800      },      {        \"name\": \"形东小\",        \"number\": 69,        \"id\": 620000197606057300      },      {        \"name\": \"属严道格入率\",        \"number\": 78,        \"id\": 54000020050702420      }    ]  }}")
   ; }
}
