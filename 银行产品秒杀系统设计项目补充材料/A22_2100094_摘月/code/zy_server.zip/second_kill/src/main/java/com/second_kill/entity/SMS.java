package com.second_kill.entity;

import lombok.AllArgsConstructor;
import lombok.Data;


@Data
@AllArgsConstructor
public class SMS {
    private String phone;
    private String code;
    private Integer min;
    private int templateId;
}
