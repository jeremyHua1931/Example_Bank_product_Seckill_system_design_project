package com.second_kill.utils.baidu;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TimeUtil {

    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    private static final DateFormat monthDayFormat = new SimpleDateFormat("MM-dd");

    private static final DateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static Date strToDate(String str) throws ParseException {
        return dateFormat.parse(str);
    }

    public static String getMonthDayStr() {
        return monthDayFormat.format(new Date());
    }

    public static Date strToDateTime(String str) throws ParseException {
        return dateTimeFormat.parse(str);
    }

    public static String getDateStr() {
        return dateFormat.format(new Date());
    }

    public static String getDateTimeStr() {
        return dateTimeFormat.format(new Date());
    }

    public static Date getDate() throws ParseException {
        return strToDate(dateFormat.format(new Date()));
    }

    public static Date getDateTime() throws ParseException {
        return strToDateTime(dateTimeFormat.format(new Date()));
    }

    public static Long getSecondsToNextDay() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return (cal.getTimeInMillis() - System.currentTimeMillis()) / 1000;
    }

    public static int daysOfLastMonth() {

        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        c.set(year, month, 0);

        return c.get(Calendar.DAY_OF_MONTH);
    }

    public static int dayOfThisMonth() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.DAY_OF_MONTH);
    }

    public static int getMonth() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.MONTH) + 1;
    }

    public static int getYear() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.YEAR);
    }

}
