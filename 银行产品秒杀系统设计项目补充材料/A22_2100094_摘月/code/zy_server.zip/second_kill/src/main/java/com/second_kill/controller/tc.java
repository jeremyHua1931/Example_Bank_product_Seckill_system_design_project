package com.second_kill.controller;

import com.second_kill.service.ILoansGoodService;
import com.second_kill.service.IPreFilterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
@RestController
public class tc {
    @Autowired
    IPreFilterService preFilterService;
    @Autowired
    ILoansGoodService loansGoodService;
    @PostMapping("/x")
    public String main() {
        preFilterService.updateFilterLoans(loansGoodService.getBaseMapper().selectById(21));
        return "1";
    }
}
