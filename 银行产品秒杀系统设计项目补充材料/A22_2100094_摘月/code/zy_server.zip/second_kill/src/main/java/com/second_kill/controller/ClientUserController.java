package com.second_kill.controller;

import com.second_kill.config.RedisPrefix;
import com.second_kill.controller.exhandler.BaseController;
import com.second_kill.entity.ResponseBean;
import com.second_kill.entity.SMS;
import com.second_kill.entity.Client;
import com.second_kill.entity.UserCode;
import com.second_kill.mapper.IClientMapper;
import com.second_kill.service.IClientService;
import com.second_kill.service.ex.SystemException;
import com.second_kill.utils.JWTUtils;
import com.second_kill.utils.Sm4Util;
import com.second_kill.utils.StringUtil;
import com.second_kill.utils.VerifyCodeUtil;
import com.second_kill.utils.baidu.Base64Util;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import redis.clients.jedis.Jedis;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import static com.second_kill.utils.JedisUtil.getJedis;


@RestController
@RequestMapping("/client/user")
public class ClientUserController extends BaseController {

    private final IClientService clientService;
    private final IClientMapper clientMapper;

    @Autowired
    ClientUserController(IClientService iClientService, IClientMapper clientMapper) {
        this.clientService = iClientService;
        this.clientMapper = clientMapper;
    }

    /**
     * @param token
     * @return
     */
    @GetMapping("/getInfo")
    public ResponseBean getInfo(@RequestHeader(value = "token") String token) {
        Integer userId = JWTUtils.JWTGetUserId(token);
        Client client = clientService.getBaseMapper().selectById(userId);
        client.setPassword(null);
        client.setSalt(null);
        if (StringUtil.isBlank(client.getIdCard())) {
            client.setIdCard(null);
        }
        if (StringUtil.isBlank(client.getName())) {
            client.setName(null);
        }
        Jedis jedis = getJedis();
        if (jedis == null) throw new SystemException("内部错误");
        client.setBalance(Double.parseDouble(jedis.hget(RedisPrefix.USER_DATA + userId.toString(), "balance")));
        return new ResponseBean(200, "success", client);
    }

    /**
     * 忘记密码、更新密码、添加密码
     *
     * @param user 用户(传入信息：phone,password)
     * @return
     */
    @PostMapping("/updatePwd")
    public ResponseBean updatePwd(@RequestBody UserCode user) throws Exception {
        int flag;
        //更新Redis 密码
        if (user.getPhone() != null) {
            flag = clientService.updatePwd(user.getPhone(), user.getVerifyCode(), user.getPassword());
        } else {
            flag = clientService.updatePwd(user.getUsername(), user.getVerifyCode(), user.getPassword());
        }
        if (flag == 1) {
            return new ResponseBean(HttpStatus.OK.value(), "更新成功", null);
        }
        return new ResponseBean(400, "更新失败", null);
    }

    /**
     * 手机密码登录
     *
     * @param client 用户(传入信息：phone,password)
     * @return
     */
    @PostMapping("/loginPwd")
    public ResponseBean loginPwd(@RequestBody Client client) throws Exception {
        Jedis jedis = getJedis();
        assert jedis != null;
       /* //判断是否登录成功
        if (client.getPhone() != null) {
            realClient = clientService.loginPwd(client.getPhone(), client.getPassword());
        } else {
            realClient = clientService.loginPwd(client.getUsername(), client.getPassword());
        }
        if (realClient == null) { //判断是否登录成功
            return new ResponseBean(HttpStatus.FORBIDDEN.value(), "账号不存在", null);
        }
        Map<String, String> map = new HashMap<>();//构造jwt的map
        String currentTimeMillis = String.valueOf(System.currentTimeMillis());
        map.put("time", currentTimeMillis);
        map.put("phone", realClient.getPhone());
        map.put("userId", realClient.getId().toString());*/
        Map<String, String> map = new HashMap<>();//构造jwt的map
        String password = client.getPassword();
        Integer userId = 0;
        String PorU = client.getPhone();
        if (Pattern.matches("^1[3-9]\\d{9}$",PorU)) {
            if (!jedis.hexists(RedisPrefix.PHONE_PASSWORD, PorU)) {
                return new ResponseBean(401, "该用户不存在", null);
            }
            com.alibaba.fastjson.JSONObject json = com.alibaba.fastjson.JSONObject.parseObject(jedis.hget(RedisPrefix.PHONE_PASSWORD, PorU));
            String realPassword = (String) json.get("password");
            String realSalt = (String) json.get("salt");
            if (!Sm4Util.verifyEcb(realSalt, realPassword, password)) {
                return new ResponseBean(400, "密码错误", null);
            }
            map.put("phone", PorU);
            userId = Integer.parseInt(String.valueOf(json.get("userId")));
            map.put("userId",userId.toString());
        } else {
            if (!jedis.hexists(RedisPrefix.USERNAME_PASSWORD, PorU)) {
                return new ResponseBean(401, "该用户不存在", null);
            }
            com.alibaba.fastjson.JSONObject json = com.alibaba.fastjson.JSONObject.parseObject(jedis.hget(RedisPrefix.USERNAME_PASSWORD, PorU));
            String realPassword = (String) json.get("password");
            String realSalt = (String) json.get("salt");
            if (!Sm4Util.verifyEcb(realSalt, realPassword, password)) {
                return new ResponseBean(400, "密码错误", null);
            }
            map.put("phone", (String) json.get("phone"));
            userId = Integer.parseInt(String.valueOf(json.get("userId")));
            map.put("userId",userId.toString());
        }
        jedis.close();
        map.put("time", String.valueOf(System.currentTimeMillis()));

        String token = JWTUtils.getToken(map);//生成token
        Map<String, Object> data = new HashMap<>();
        data.put("token", token);
        data.put("userId", userId);
        return new ResponseBean(HttpStatus.OK.value(), "登录成功", data);
    }

    /**
     * 手机验证码登录
     *
     * @param sms sms实体(手机号、验证码)
     * @return
     */
    @PostMapping("/loginSMS")
    public ResponseBean loginSMS(@RequestBody SMS sms) {
        String verifyRes = VerifyCodeUtil
                .checkVerifyCode(sms.getPhone(), Integer.parseInt(sms.getCode()));
        //验证码验证不需要读取数据库，速度更快，优先判断。完成后判断用户是否存在

        switch (verifyRes) {
            case "success":
                Client realClient = clientService.checkPhone(sms.getPhone());
                if (realClient == null) { //判断是否登录成功
                    return new ResponseBean(HttpStatus.FORBIDDEN.value(), "账号不存在", null);
                }
                Map<String, String> map = new HashMap<>();//构造jwt的map

                String currentTimeMillis = String.valueOf(System.currentTimeMillis());
                map.put("time", currentTimeMillis);
                map.put("phone", realClient.getPhone());
                map.put("userId", realClient.getId().toString());
                String token = JWTUtils.getToken(map);//生成token

                Map<String, Object> data = new HashMap<>();
                data.put("token", token);
                data.put("userId", realClient.getId());
                return new ResponseBean(HttpStatus.OK.value(), "登录成功", data);
            case "outDate":
                return new ResponseBean(400, "验证码过期", null);
            case "notMatch":
                return new ResponseBean(401, "验证码错误", null);
            default:
                return new ResponseBean(500, "内部错误", null);
        }
    }

    @GetMapping("/getCode")
    public ResponseBean getCode(String phone, Integer action) {
        if (StringUtil.isBlank(phone)) {
            return new ResponseBean(500, "手机号未填写", null);
        }
        VerifyCodeUtil.sendVerifyCodeSms(phone, action);
        return new ResponseBean(200, "验证码已发送", null);
    }

    /**
     * 注册
     *
     * @param user 用户信息
     * @return
     */
    @PostMapping("/register")
    public ResponseBean register(@RequestBody UserCode user) throws Exception {
        String verifyRes = VerifyCodeUtil
                .checkVerifyCode(user.getPhone(), user.getVerifyCode());
        //验证码验证不需要读取数据库，速度更快，优先判断。完成后判断用户是否存在
        Jedis jedis = getJedis();

        switch (verifyRes) {
            case "success":
                clientService.register(user.getPhone(), user.getUsername(), user.getPassword(), user.getVerifyCode());
                return new ResponseBean(200, "注册成功", null);
            case "outDate":
                return new ResponseBean(400, "验证码过期", null);
            case "notMatch":
                return new ResponseBean(401, "验证码错误", null);
            default:
                return new ResponseBean(500, "内部错误", null);
        }

    }


    /**
     * 修改信息
     *
     * @param client
     * @return
     */
    @PostMapping("/editInfo")
    public ResponseBean editInfo(@RequestHeader(value = "token") String token, @RequestBody Client client) {
        Integer userId = JWTUtils.JWTGetUserId(token);
        client.setId(userId);
        clientService.editInfo(client);
        return new ResponseBean(200, "修改成功", null);
    }

    /**
     * 添加身份证信息
     *
     * @param file
     * @return
     */
    @PostMapping("/addIdCard")
    public ResponseBean addIdCard(MultipartFile file) {
        if (file == null) {
            throw new SystemException("文件为空");
        }
        String oldFileName = file.getOriginalFilename();
        assert oldFileName != null;
        String eName = oldFileName.substring(oldFileName.lastIndexOf("."));
        if (!eName.equals(".jpg") && !eName.equals(".png") && !eName.equals(".jpeg")) {
            throw new SystemException("文件格式错误");
        }
        try {
            Map<String, String> data = new HashMap<>();
            String clientId = "qarGcNQ6FP2MHmCuVWVi4tva";
            // 官网获取的 Secret Key 更新为你注册的
            String clientSecret = "tELqV3xYlbVKvw61XTt1y52MAILwGnSR";
            String access_token = getAuth(clientId, clientSecret);
            //调用身份证识别
            String request_url = "https://aip.baidubce.com/rest/2.0/ocr/v1/idcard";
            String url = request_url + "?access_token=" + access_token;
            String img_str = convertFileToBase64(file);
            String imgParam = "";
            try {
                imgParam = URLEncoder.encode(img_str, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            String params = "image=" + imgParam + "&id_card_side=front" + "&detect_risk=true" + "&detect_photo=false" + "&detect_risk=true";
            String res = sendPost(url, params);
            com.alibaba.fastjson.JSONObject json = com.alibaba.fastjson.JSONObject.parseObject(res);
            System.out.println(json);
            if (json.get("risk_type").equals("copy") || json.get("risk_type").equals("temporary") || json.get("risk_type").equals("screen") || json.get("risk_type").equals("unknown")) {
                return new ResponseBean(500, "请使用符合规则的身份证", null);
            }
            com.alibaba.fastjson.JSONObject words_result = (com.alibaba.fastjson.JSONObject) json.get("words_result");
            com.alibaba.fastjson.JSONObject nameResult = (com.alibaba.fastjson.JSONObject) words_result.get("姓名");
            String name = (String) nameResult.get("words");
            com.alibaba.fastjson.JSONObject idResult = (com.alibaba.fastjson.JSONObject) words_result.get("公民身份号码");
            String idCard = (String) idResult.get("words");
            data.put("name", name);
            data.put("idCard", idCard);
            return new ResponseBean(200, "返回成功", data);
        } catch (Exception e) {
            e.printStackTrace();
            throw new SystemException("请重新拍照");
        }

    }

    /**
     * 将身份证信息加入
     *
     * @return
     */
    @PostMapping("/insertIdCard")
    public ResponseBean insertIdCard(@RequestHeader(value = "token") String token, @RequestBody Client client) {
        Integer userId = JWTUtils.JWTGetUserId(token);
        String idCard = client.getIdCard();
        String name = client.getName();
        clientMapper.updateName(userId, idCard, name);
        return new ResponseBean(200, "添加成功", null);
    }

    //post请求方法
    public static String sendPost(String url, String param) {
        StringBuilder result = new StringBuilder();
        try {
            URL httpurl = new URL(url);
            HttpURLConnection httpConn = (HttpURLConnection) httpurl.openConnection();
            httpConn.setDoOutput(true);
            httpConn.setDoInput(true);
            PrintWriter out = new PrintWriter(httpConn.getOutputStream());
            out.print(param);
            out.flush();
            out.close();
            BufferedReader in = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            in.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return result.toString();
    }

    //图片转base64
    public static String convertFileToBase64(MultipartFile file) {
        byte[] data = null;
        // 读取图片字节数组
        try {
            /*
              byte[] bytes = file.getBytes();
              InputStream in = new ByteArrayInputStream(bytes);
              该代码可以将MultipartFile类型的文件转换为InputStream流
             */
            byte[] bytes = file.getBytes();
            InputStream in = new ByteArrayInputStream(bytes);
            //System.out.println("文件大小（字节）="+in.available());
            data = new byte[in.available()];
            in.read(data);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 对字节数组进行Base64编码，得到Base64编码的字符串
        return Base64Util.encode(data);
    }

    //获取access_token
    public static String getAuth(String ak, String sk) {
        // 获取token地址
        String authHost = "https://aip.baidubce.com/oauth/2.0/token?";
        String getAccessTokenUrl = authHost
                // 1. grant_type为固定参数
                + "grant_type=client_credentials"
                // 2. 官网获取的 API Key
                + "&client_id=" + ak
                // 3. 官网获取的 Secret Key
                + "&client_secret=" + sk;
        try {
            URL realUrl = new URL(getAccessTokenUrl);
            // 打开和URL之间的连接
            HttpURLConnection connection = (HttpURLConnection) realUrl.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();
            // 获取所有响应头字段
            Map<String, List<String>> map = connection.getHeaderFields();

            // 定义 BufferedReader输入流来读取URL的响应
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder result = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }

            JSONObject jsonObject = new JSONObject(result.toString());
            return jsonObject.getString("access_token");
        } catch (Exception e) {
            System.err.print("获取token失败！");
            e.printStackTrace(System.err);
        }
        return null;
    }
}



