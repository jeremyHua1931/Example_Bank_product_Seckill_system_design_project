package com.second_kill.utils;

import com.second_kill.entity.SMS;
import com.second_kill.service.ex.SystemException;
import redis.clients.jedis.Jedis;

import java.util.Date;
import java.util.Objects;
import java.util.Random;
import java.util.regex.Pattern;

import static com.second_kill.utils.JedisUtil.getJedis;

/**
 * 用于支持验证码登录的组件
 *
 * @author zxypp
 */
public class VerifyCodeUtil {
    /**
     * 发送短消息，如果失败则抛出SystemException
     *
     * @param phone  手机号
     * @param action 0注册，1登录
     * @return sms对象
     */
    public static void sendVerifyCodeSms(String phone, Integer action) {
        //校验手机号格式
        if (!Pattern.matches("^1[3-9]\\d{9}$", phone)) {
            throw new SystemException("非法的手机号");
        }
        /*
        选择templateId
            修改 1109984 code
            登录 1109983 code min
            注册 1109982 code min
         */
        int templateId;
        if (action == 1) {
            templateId = 1109983;
        } else if (action == 2) {
            templateId = 1109982;
        } else templateId = 1109982;

        Long date = new Date().getTime();
        Jedis jedis = getJedis();
        if (jedis == null) {
            throw new SystemException("内部错误");
        }
        //检查验证码间隔
        if (jedis.exists(phone) && Long.parseLong(jedis.lindex(phone, 0)) >= date - 60000) {
            jedis.close();
            throw new SystemException("验证码发送过于频繁");
        }
        //创建sms对象，生成验证码
        Random random = new Random();
        String code = String.valueOf((random.nextInt(899999) + 100000));
        jedis.del(phone);
        jedis.lpush(phone, code);
        jedis.lpush(phone, String.valueOf(date));
        System.out.print(phone);
        System.out.print("已发送验证码：");
        System.out.println(code);
        SMS sms = new SMS(phone, code, 4, templateId);
        //发送短消息
        String smsRes = SMSUtil.sendSMS(sms);
        //String smsRes="success";
        if (!Objects.equals(smsRes, "success")) {
            jedis.del(phone);
            jedis.close();
            throw new SystemException("验证码发送失败");
        }
        jedis.close();
    }

    /**
     * 检查验证码是否正确，如果正确将删除已经存储的验证码
     *
     * @param phone 手机号
     * @param code  验证码
     * @return String 返回outDate,notMatch,success中的一个
     */
    public static String checkVerifyCode(String phone, Integer code) {
        return checkVerifyCode(phone, code, true);
    }

    /**
     * 检查验证码是否正确
     *
     * @param phone     手机号
     * @param code      验证码
     * @param clearCode 验证成功是否删除验证码
     * @return String 返回outDate,notMatch,success中的一个
     */
    public static String checkVerifyCode(String phone, Integer code, boolean clearCode) {
        long date = new Date().getTime();
        Jedis jedis = getJedis();
        if (jedis == null) {
            throw new SystemException("内部错误");
        }
        //检查验证码时效
        if (!jedis.exists(phone) || Long.parseLong(jedis.lindex(phone, 0)) <= date - 240000) {
            jedis.close();
            return "outDate";
        }
        //检查验证码
        if (Long.parseLong(jedis.lindex(phone, 1)) != code) {
            jedis.close();
            return "notMatch";
        }
        if (clearCode) {
            jedis.del(phone);
        }
        jedis.close();
        return "success";
    }

    /**
     * 删除存储的验证码
     *
     * @param phone 手机号
     */
    public static void clearVerifyCode(String phone) {
        Jedis jedis = getJedis();
        if (jedis == null) {
            throw new SystemException("内部错误");
        }
        jedis.close();
        jedis.del(phone);
    }
}
