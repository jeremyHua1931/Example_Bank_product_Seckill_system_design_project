package com.second_kill.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.second_kill.entity.*;

public interface IDepositsGoodService extends IService<DepositGood> {
    PagesBean search(GoodSearch goodSearch);

    PagesBean getDepositListById(OrderFactor orderFactor);

    PagesBean getAllOrder(AllOrderFactor orderFactor);
}
