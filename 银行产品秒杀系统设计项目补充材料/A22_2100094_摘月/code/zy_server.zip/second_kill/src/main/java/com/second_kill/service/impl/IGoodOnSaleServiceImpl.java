package com.second_kill.service.impl;

import com.aliyun.openservices.shade.com.alibaba.fastjson.JSON;
import com.second_kill.config.RedisPrefix;
import com.second_kill.entity.*;
import com.second_kill.mapper.IDepositOrderMapper;
import com.second_kill.mapper.ILoansOrderMapper;
import com.second_kill.service.IBalancePutterService;
import com.second_kill.service.IClientService;
import com.second_kill.service.IGoodOnSaleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.Transaction;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.second_kill.utils.JedisUtil.getJedis;

@Service
public class IGoodOnSaleServiceImpl implements IGoodOnSaleService {
    @Autowired
    private IClientService clientService;
    @Autowired
    private IDepositOrderMapper depositOrderMapper;
    @Autowired
    private ILoansOrderMapper loansOrderMapper;
    private double companyAccount = 0.0;

    /**
     * 初始化商品类型(贷款)
     *
     * @param good 商品
     */
    @Override
    public void initGoodInfo(LoansGood good) {
        System.out.println("正在初始化商品信息L:"+good.getId());
        Jedis jedis = getJedis();
        assert jedis != null;
        jedis.del(RedisPrefix.GOOD_LOANS_INFO + good.getId().toString());
        jedis.hgetAll(RedisPrefix.USER_PASSWORD).forEach((k, v) -> {
            jedis.hdel(RedisPrefix.USER_DATA + k, RedisPrefix.GOOD_LOANS_USER + good.getId().toString());
        });

        Map<String, String> infoMap = new HashMap<>(), userMap = new HashMap<>();

        infoMap.put("total", good.getTotalNumber().toString());
        infoMap.put("remain", good.getRemainNumber().toString());
        infoMap.put("restrict", good.getRestrictNumber().toString());
        infoMap.put("price", good.getPrice().toString());
        infoMap.put("isFilter", good.getIsFilter().toString());
        infoMap.put("startTime", String.valueOf(good.getStartTime().getTime()));
        infoMap.put("endTime", String.valueOf(good.getEndTime().getTime()));
        infoMap.put("name", good.getName());
        infoMap.put("repeatDelay", good.getRepeatDelay().toString());
        infoMap.put("repeatTimes", good.getRepeatTimes().toString());

        jedis.hset(RedisPrefix.GOOD_LOANS_INFO + good.getId().toString(), infoMap);
        jedis.close();
        System.out.println("初始化结束商品信息L:"+good.getId());
    }

    /**
     * 初始化商品类型
     *
     * @param good 是否贷款
     */
    @Override
    public void initGoodInfo(DepositGood good) {
        System.out.println("正在初始化商品信息D:"+good.getId());
        Jedis jedis = getJedis();
        assert jedis != null;
        jedis.del(RedisPrefix.GOOD_DEPOSIT_INFO + good.getId().toString());
        jedis.hgetAll(RedisPrefix.USER_PASSWORD).forEach((k, v) -> {
            jedis.hdel(RedisPrefix.USER_DATA + k, RedisPrefix.GOOD_DEPOSIT_USER + good.getId().toString());
        });
        Map<String, String> infoMap = new HashMap<>();

        infoMap.put("total", good.getTotalNumber().toString());
        infoMap.put("remain", good.getRemainNumber().toString());
        infoMap.put("restrict", good.getRestrictNumber().toString());
        infoMap.put("price", good.getPrice().toString());
        infoMap.put("isFilter", good.getIsFilter().toString());
        infoMap.put("startTime", String.valueOf(good.getStartTime().getTime()));
        infoMap.put("endTime", String.valueOf(good.getEndTime().getTime()));
        infoMap.put("name", good.getName());
        infoMap.put("repeatDelay", good.getRepeatDelay().toString());
        infoMap.put("repeatTimes", good.getRepeatTimes().toString());
        jedis.hset(RedisPrefix.GOOD_DEPOSIT_INFO + good.getId().toString(), infoMap);
        jedis.close();
        System.out.println("初始化结束商品信息D:"+good.getId());
    }


    /**
     * 扣库存并创建订单，创建订单阶段<br>
     * 该方法将先检查用户余量和商品余量，若可以购买则创建订单ID并减少两个余量<br>
     * 该方法已使用CAS<br>
     *
     * @param order orderInfo对象
     * @return -1:表更改失败,-2:商品不足或超过限购，部分成功,-3:商品不足，-4:超过限购，失败，0：成功
     */
    @Override
    public Integer createOrder(OrderInfo order, Jedis jedis) {
        if (jedis == null) {
            order.setStatus(-1);
            return -1;
        }

        boolean isLoans = order.getIsLoans();
        Integer number = order.getNumber();
        Integer userId = order.getUserId();
        Integer goodId = order.getGoodId();

        if (!isGoodInSale(isLoans, goodId, jedis)) {
            order.setStatus(-6);
            order.setMsg("商品未开始或已结束");
            jedis.close();
            return -6;
        }

        // 存了用户所有属性的Redis键名
        String userKey = RedisPrefix.USER_DATA + userId;
        //用户属性中对应商品限购的Hash键名
        String userHKey = (isLoans ? RedisPrefix.GOOD_LOANS_USER : RedisPrefix.GOOD_DEPOSIT_USER) + goodId;
        String goodsKey = (isLoans ? RedisPrefix.GOOD_LOANS_INFO : RedisPrefix.GOOD_DEPOSIT_INFO) + goodId;
        String IdKey = isLoans ? RedisPrefix.ORDER_ID_LOANS : RedisPrefix.ORDER_ID_DEPOSIT;
        boolean filterFail;
        if (jedis.hget(goodsKey, "isFilter").equals("1")) {
            filterFail = false;
            if (isLoans) {
                if (!jedis.hexists(RedisPrefix.FILTER_LOANS_RESULT + goodId, order.getUserId().toString())) {
                    filterFail = true;
                } else if (!jedis.hget(RedisPrefix.FILTER_LOANS_RESULT + goodId, order.getUserId().toString()).equals("pass")) {
                    filterFail = true;
                }
            } else {
                if (!jedis.hexists(RedisPrefix.FILTER_DEPOSIT_RESULT + goodId, order.getUserId().toString())) {
                    filterFail = true;
                } else if (!jedis.hget(RedisPrefix.FILTER_DEPOSIT_RESULT + goodId, order.getUserId().toString()).equals("pass")) {
                    filterFail = true;
                }
            }
        } else filterFail = false;

        if (filterFail) {
            order.setStatus(-5);
            order.setNumber(null);
        } else {
            order.setStatus(0);
            {
                int gremain = Integer.parseInt(jedis.hget(goodsKey, "remain"));
                if (gremain == 0) {
                    order.setStatus(-3);
                    jedis.close();
                    return -3;
                }
            }
            for (int i = 0; i < 40; i++) {
                jedis.watch(goodsKey, userKey, IdKey);
                Integer gremain = Integer.parseInt(jedis.hget(goodsKey, "remain"));
                Integer uremain;
                if (!jedis.hexists(userKey, userHKey))
                    uremain = Integer.parseInt(jedis.hget(goodsKey, "restrict"));
                else
                    uremain = Integer.parseInt(jedis.hget(userKey, userHKey));

                String tmpIdKey = jedis.get(IdKey);
                if (tmpIdKey == null) continue;
                Integer orderId = Integer.parseInt(tmpIdKey) + 1;
                if (gremain < number || uremain < number) {
                    if (gremain == 0) {
                        order.setStatus(-3);
                        break;
                    } else if (uremain == 0) {
                        order.setStatus(-4);
                        break;
                    } else {
                        order.setStatus(-2);
                        number = Math.min(gremain, uremain);
                        order.setNumber(number);
                    }
                }
                Transaction ts = jedis.multi();
                ts.hset(userKey, userHKey, String.valueOf(uremain - number));
                ts.hset(goodsKey, "remain", String.valueOf(gremain - number));
                ts.set(IdKey, String.valueOf(orderId));
                if (!CollectionUtils.isEmpty(ts.exec())) {
                    Double singlePrice = Double.parseDouble(jedis.hget(goodsKey, "price"));
                    order.setOrderId(orderId);
                    order.setPaid(false);
                    order.setTotalPrice(singlePrice * number);
                    order.setName(jedis.hget(goodsKey, "name"));
                    //如果没有错误发生，则order的状态应该为0
                    break;
                } else {
                    if (i == 39) {
                        jedis.close();
                        order.setStatus(-1);
                        break;
                    }
                }
            }
        }
        jedis.close();
        return order.getStatus();
    }

    @Override
    public Boolean isGoodInSale(Boolean isLoans, Integer goodId, Jedis jedis) {
        String goodsKey = (isLoans ? RedisPrefix.GOOD_LOANS_INFO : RedisPrefix.GOOD_DEPOSIT_INFO) + goodId;
        long endTime = Long.parseLong(jedis.hget(goodsKey, "endTime"));
        long startTime = Long.parseLong(jedis.hget(goodsKey, "startTime"));
        jedis.close();
        //此处判断商品结束售卖
        return endTime >= System.currentTimeMillis() || startTime <= System.currentTimeMillis();
    }

    /**
     * ***退钱。-1：系统繁忙，-2订单未找到，-3订单正在处理，0成功
     *
     * @param order  对象
     * @param userId 用户ID
     */
    @Override
    public Integer payBackOrder(OrderInfo order, Integer userId) {
        //TODO 需要高负载和极端情况测试
        Jedis jedis = getJedis();
        assert jedis != null;
        Boolean isLoans = order.getIsLoans();
        Integer orderId = order.getOrderId();
//        Integer goodId = order.getGoodId();
        String refundKey = isLoans ? RedisPrefix.ORDER_LOANS_REFUND : RedisPrefix.ORDER_DEPOSIT_REFUND;
        OrderInfo realOrder = null;
        LoansOrder dbOrderL;
        DepositOrder dbOrderD;
        if (jedis.hexists(refundKey, String.valueOf(order.getOrderId()))) {
            String tmpVal = jedis.hget(refundKey, String.valueOf(order.getOrderId()));
            if (tmpVal.equals("processing")) {
                //成功，但是之前已经提交且还没运行完的：提示一下
                jedis.close();
                return -3;
            }
            realOrder = JSON.parseObject(tmpVal, OrderInfo.class);
        } else if (jedis.hexists(isLoans ? RedisPrefix.ORDER_LOANS : RedisPrefix.ORDER_DEPOSIT, order.getOrderId().toString())) {
            //默认状态：从Redis中读取订单信息
            realOrder = JSON.parseObject(jedis.hget(isLoans ? RedisPrefix.ORDER_LOANS : RedisPrefix.ORDER_DEPOSIT, order.getOrderId().toString()), OrderInfo.class);
            jedis.hdel(isLoans ? RedisPrefix.ORDER_LOANS : RedisPrefix.ORDER_DEPOSIT, order.getOrderId().toString());
        } else if (isLoans && (dbOrderL = loansOrderMapper.selectById(orderId)) != null) {
            //读取失败：尝试读取Mysql
            realOrder = new OrderInfo(dbOrderL);
        } else if (!isLoans && (dbOrderD = depositOrderMapper.selectById(orderId)) != null) {
            //读取失败：尝试读取Mysql
            realOrder = new OrderInfo(dbOrderD);
        }

        //还是失败：骗钱的，返回错误
        if (realOrder == null) {
            jedis.close();
            return -2;
        }
        //成功了，但是不是自己的单：骗钱的，返回错误
        if (!Objects.equals(realOrder.getUserId(), userId)) {
            jedis.close();
            return -2;
        }
        //成功，但是之前已经提交退款了：搞事情的，返回错误
        if (realOrder.getStatus() == -2) {
            jedis.close();
            return -2;
        }
        //设置正在退单标记
        jedis.hset(refundKey, String.valueOf(realOrder.getOrderId()), "processing");
        //回滚订单（函数中含有是否需要回滚的判断，故无需再次单独判断）
        if (!rollBackOrder(realOrder, jedis)) {
            //滚单未成功：订单加入退单队列等待被存入数据库或再次处理
            jedis.hset(refundKey, String.valueOf(realOrder.getOrderId()), JSON.toJSONString(realOrder));
            jedis.close();
            return -1;
        }
        realOrder.setNumber(0);
        //已付款的订单：退钱
        if (realOrder.getPaid()) {
            if (addBalance(realOrder.getUserId(), realOrder.getTotalPrice(), jedis) != 0) {
                //已滚单，但是
                realOrder.setStatus(-1);
                jedis.hset(refundKey, String.valueOf(realOrder.getOrderId()), JSON.toJSONString(realOrder));
                jedis.close();
                return -1;
            }
        }
        //已滚单，退款已处理
        realOrder.setNumber(0);
        realOrder.setTotalPrice(0.0);
        realOrder.setStatus(-2);
        jedis.hset(refundKey, String.valueOf(realOrder.getOrderId()), JSON.toJSONString(realOrder));
        jedis.close();
        return 0;
    }

    /**
     * 修改用户余额（带锁）
     *
     * @param userId 用户Id
     * @param change 改变量（正数加）
     * @return 0成功，-1系统繁忙，-2余额不足
     */
    @Override
    public Integer addBalance(Integer userId, Double change, Jedis jedis) {
        for (int i = 0; i < 40; i++) {
            jedis.watch(RedisPrefix.USER_DATA + userId.toString());
            Double balance = Double.parseDouble(jedis.hget(RedisPrefix.USER_DATA + userId, "balance"));
            if (balance + change < 0) {
                jedis.close();
                return -2;
            }

            Transaction ts = jedis.multi();
            ts.hset(RedisPrefix.USER_DATA + userId, "balance", String.valueOf(balance + change));
            if (!CollectionUtils.isEmpty(ts.exec())) {
                setCompanyAccount(-change, true);
                jedis.close();
                return 0;
            }
        }
        return -1;
    }

    /**
     * 回滚创建的订单，用于过期商品加回库存
     *
     * @param order orderInfo对象
     * @return false:系统繁忙，true：成功或无需回滚
     */
    @Override
    public Boolean rollBackOrder(OrderInfo order) {
        Jedis jedis = getJedis();
        assert jedis != null;
        Boolean tmp = rollBackOrder(order, jedis);
        jedis.close();
        return tmp;
    }

    private Boolean rollBackOrder(OrderInfo order, Jedis jedis) {
        boolean isLoans = order.getIsLoans();
        Integer number = order.getNumber();
        if (number == 0) {
            jedis.close();
            return true;
        }
        Integer userId = order.getUserId();
        Integer goodId = order.getGoodId();
        System.out.println(order.getOrderId() + "准备回滚");
        //如果没有错误发生，则order的状态应该为0
        order.setStatus(0);
        String userKey = RedisPrefix.USER_DATA + userId;
        String userHKey = (isLoans ? RedisPrefix.GOOD_LOANS_USER : RedisPrefix.GOOD_DEPOSIT_USER) + goodId;
        String goodsKey = (isLoans ? RedisPrefix.GOOD_LOANS_INFO : RedisPrefix.GOOD_DEPOSIT_INFO) + goodId;

        for (int i = 0; i < 40; i++) {
            if (i == 39) {
                jedis.close();
                return false;
            }
            if (!jedis.exists(goodsKey) || !jedis.exists(userKey) || !jedis.hexists(userKey, userHKey)) {
                jedis.close();
                return true;
            }
            jedis.watch(goodsKey, userKey);
            if (!isGoodInSale(isLoans, goodId, jedis)) break;
            Integer gremain = Integer.valueOf(jedis.hget(goodsKey, "remain"));

            int uremain;
            if (!jedis.hexists(userKey, userHKey))
                uremain = 0;
            else
                uremain = Integer.parseInt(jedis.hget(userKey, userHKey));

            Transaction ts = jedis.multi();
            ts.hset(userKey, userHKey, String.valueOf(uremain + number));
            ts.hset(goodsKey, "remain", String.valueOf(gremain + number));
            if (!CollectionUtils.isEmpty(ts.exec())) {
                break;
            }
        }
        jedis.close();
        return true;
    }

    /**
     * 生成队列ID<br>
     * QueueID用于前端轮询获取Status和OrderId<br>
     * QueueID为用户ID和时间对15分钟取模的拼接串
     *
     * @param userId 商品ID
     * @return String 队列ID
     */
    public String getQueueId(Integer userId) {
        return userId + "-" + (System.currentTimeMillis() % 900000);
    }

    @Override
    synchronized public Double getCompanyAccount() {
        return this.companyAccount;
    }

    @Override
    synchronized public void setCompanyAccount(double companyAccount, Boolean relative) {
        //if(companyAccount==null||companyAccount.isNaN())companyAccount=0.0;
        if (relative == null || relative.equals(false)) {
            this.companyAccount = companyAccount;
        } else this.companyAccount += companyAccount;
    }
}
