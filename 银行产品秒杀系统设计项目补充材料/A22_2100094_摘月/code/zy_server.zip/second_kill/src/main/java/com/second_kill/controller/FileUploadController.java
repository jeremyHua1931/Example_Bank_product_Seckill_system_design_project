package com.second_kill.controller;

import com.qcloud.cos.COSClient;
import com.qcloud.cos.model.PutObjectRequest;
import com.second_kill.controller.exhandler.BaseController;
import com.second_kill.entity.ResponseBean;
import com.second_kill.service.ex.SystemException;
import com.second_kill.utils.COSClientUtil;
import com.second_kill.utils.baidu.FileUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@RestController
public class FileUploadController extends BaseController {
    //存储桶空间名称
    @Value("${spring.qcloud.bucketName}")
    private String bucketName;
    //存储桶访问域名
    @Value("${spring.qcloud.url}")
    private String url;
    //上传文件前缀路径(eg:/images/)
    @Value("${spring.qcloud.prefix}")
    private String prefix;

    @PostMapping("/file/image")
    public ResponseBean fileUpload(MultipartFile file) {
        if (file == null) {
            throw new SystemException("文件为空");
        }
        String oldFileName = file.getOriginalFilename();
        assert oldFileName != null;
        String eName = oldFileName.substring(oldFileName.lastIndexOf("."));
        if (!eName.equals(".jpg") && !eName.equals(".png") && !eName.equals(".jpeg") && !eName.equals(".gif")) {
            throw new SystemException("文件格式错误");
        }
        String newFileName = FileUtil.getFileName(oldFileName, eName);
        COSClient cosclient = COSClientUtil.getCOSClient();
        String bucketName = this.bucketName;
        File localFile;
        try {
            localFile = File.createTempFile("temp", null);
            file.transferTo(localFile);
            // 指定要上传到 COS 上的路径
            String key = "/" + this.prefix + "/" + FileUtil.getFilePath() + newFileName;
            PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, key, localFile);
            cosclient.putObject(putObjectRequest);
            return new ResponseBean(HttpStatus.OK.value(), "上传成功(Upload Success)", this.url + putObjectRequest.getKey());
        } catch (IOException e) {
            return new ResponseBean(HttpStatus.OK.value(), e.getMessage(), null);
        } finally {
            // 关闭客户端(关闭后台线程)
            cosclient.shutdown();
        }
    }
}
