package com.second_kill.interceptor;

import com.auth0.jwt.exceptions.AlgorithmMismatchException;
import com.auth0.jwt.exceptions.SignatureVerificationException;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.second_kill.utils.JWTUtils;
import com.second_kill.utils.StringUtil;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

public class JWTInterceptor implements HandlerInterceptor {
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (request.getMethod().equals("OPTIONS")) return true;


        Map<String, Object> map = new HashMap<>();
        String token = request.getHeader("token");
        if (StringUtil.isBlank(token)) {
            map.put("msg", "token不存在!");
        } else
            try {
                if(request.getRequestURI().startsWith("/admin/")){
                    //判断为管理员接口地址
                    if(JWTUtils.JWTGetIsAdmin(token)){
                        return true;//放行请求
                    }else{
                        map.put("msg", "非管理员账号");
                    }
                }else{
                    //判断为用户接口
                    JWTUtils.verify(token);
                    return true;//放行请求
                }
            } catch (SignatureVerificationException e) {
                e.printStackTrace();
                map.put("msg", "无效签名!");
            } catch (TokenExpiredException e) {
                e.printStackTrace();
                map.put("msg", "token过期!");
            } catch (AlgorithmMismatchException e) {
                e.printStackTrace();
                map.put("msg", "token算法不一致!");
            } catch (Exception e) {
                e.printStackTrace();
                map.put("msg", "token无效!!");
            }
        map.put("code", 403);//设置状态
        //将map 专为json  jackson
        String json = new ObjectMapper().writeValueAsString(map);
        response.setContentType("application/json;charset=UTF-8");
        response.getWriter().println(json);
        return false;
    }
}
