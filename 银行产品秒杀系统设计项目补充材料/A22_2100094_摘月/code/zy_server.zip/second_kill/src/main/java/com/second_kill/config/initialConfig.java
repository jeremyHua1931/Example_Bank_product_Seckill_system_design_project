package com.second_kill.config;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.second_kill.entity.Client;
import com.second_kill.mapper.IClientMapper;
import com.second_kill.mapper.IDepositOrderMapper;
import com.second_kill.mapper.ILoansOrderMapper;
import com.second_kill.service.IGoodOnSaleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.Pipeline;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.second_kill.utils.JedisUtil.getJedis;

/**
 * 此处执行初始化设置
 * - 从Mysql中同步最大OrderId并存储至Redis
 */
@Component
public class initialConfig implements ApplicationRunner {
    @Autowired
    ILoansOrderMapper loansOrderMapper;
    @Autowired
    IDepositOrderMapper depositOrderMapper;
    @Autowired
    IClientMapper clientMapper;
    @Autowired
    IGoodOnSaleService goodOnSaleService;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        System.out.println("进入初始化");
        Jedis jedis = getJedis();
        assert jedis != null;
        Integer global_max_orderId_loans = loansOrderMapper.getMaxOrderId();
        Integer global_max_orderId_deposit = depositOrderMapper.getMaxOrderId();
        QueryWrapper<Client> qw = new QueryWrapper<>();
        qw.select("salt","phone","id","username","password","balance");
        List<Client> clients = clientMapper.selectList(qw);
        //Map<String, String> passwordMap = new HashMap<>();
        Integer pipeLinedCount = 0,tpipecnt=0;
        Pipeline pipeline = jedis.pipelined();

        for (Client client : clients) {
            Map<String, String> SaltAndPassword = new HashMap<>();
            Map<String, String> clientInfo = new HashMap<>();
            SaltAndPassword.put("salt", client.getSalt());
            SaltAndPassword.put("password", client.getPassword());

            clientInfo.put("salt", client.getSalt());
            clientInfo.put("password", client.getPassword());
            clientInfo.put("phone", client.getPhone());
            clientInfo.put("userId", client.getId().toString());

            pipeline.hset(RedisPrefix.USER_DATA + client.getId(), "balance", String.valueOf(client.getBalance()));//存储每一个用户的余额
            pipeline.hset(RedisPrefix.PHONE_PASSWORD, client.getPhone(), JSON.toJSONString(clientInfo));//存储密码（手机）
            pipeline.hset(RedisPrefix.USERNAME_PASSWORD, client.getUsername(), JSON.toJSONString(clientInfo));//存储密码（用户名）
            if (client.getId() == 0) {
                goodOnSaleService.setCompanyAccount(client.getBalance(), false);
            }
            //passwordMap.put(String.valueOf(client.getId()), JSON.toJSONString(SaltAndPassword));
            pipeline.hset(RedisPrefix.USER_PASSWORD,String.valueOf(client.getId()),JSON.toJSONString(SaltAndPassword));
            pipeLinedCount++;
            if(pipeLinedCount>50){
                pipeLinedCount=0;
                pipeline.sync();
                pipeline.close();
                pipeline = jedis.pipelined();
                System.out.println("初始化_用户数据已传送：分片-"+(++tpipecnt));
            }
        }
        if(pipeLinedCount>0)
            pipeline.sync();
        pipeline.close();

        //jedis.hset(RedisPrefix.USER_PASSWORD, passwordMap);

        if (global_max_orderId_deposit == null) global_max_orderId_deposit = 1;
        if (global_max_orderId_loans == null) global_max_orderId_loans = 1;

        if (!jedis.exists(RedisPrefix.ORDER_ID_LOANS))
            jedis.set(RedisPrefix.ORDER_ID_LOANS, String.valueOf(global_max_orderId_loans));
        if (!jedis.exists(RedisPrefix.ORDER_ID_DEPOSIT))
            jedis.set(RedisPrefix.ORDER_ID_DEPOSIT, String.valueOf(global_max_orderId_deposit));

        System.out.println("FINISHED");
        jedis.close();
    }
}