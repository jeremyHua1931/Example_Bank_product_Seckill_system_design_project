package com.second_kill.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.second_kill.entity.AllOrderFactor;
import com.second_kill.entity.ClientOrder;
import com.second_kill.entity.DepositOrder;
import com.second_kill.entity.OrderFactor;

import java.util.List;

public interface IDepositOrderMapper extends BaseMapper<DepositOrder> {
    List<DepositOrder> getDepositOrder(OrderFactor orderFactor);

    List<DepositOrder> getAllOrder(AllOrderFactor orderFactor);

    Integer getMaxOrderId();

    List<DepositOrder> getClientOrder(ClientOrder order);

    Integer getOrderNumber(AllOrderFactor orderFactor);
}
