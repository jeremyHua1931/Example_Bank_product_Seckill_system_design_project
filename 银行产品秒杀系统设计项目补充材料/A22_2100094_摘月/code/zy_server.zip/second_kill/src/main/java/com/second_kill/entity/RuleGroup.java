package com.second_kill.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "rule_group", autoResultMap = true)
public class RuleGroup implements Serializable {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private String name;
    private String description;
    @TableField(typeHandler = JacksonTypeHandler.class) //此注解可以将List<String>转换为json格式，插入到json字段中。
    private List<Integer> ruleList;
}
