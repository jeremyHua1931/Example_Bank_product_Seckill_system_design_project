package com.second_kill.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.second_kill.entity.Rule;
import com.second_kill.mapper.IRuleMapper;
import com.second_kill.service.IRuleService;
import com.second_kill.service.ex.SystemException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class IRuleServiceImpl extends ServiceImpl<IRuleMapper, Rule> implements IRuleService {

    @Autowired
    IRuleMapper ruleMapper;

    /**
     * 添加规则
     *
     * @param rule
     */
    @Override
    public void addRule(Rule rule) {
        ruleMapper.insert(rule);
    }

    /**
     * 删除规则
     *
     * @param id
     */
    @Override
    public void deleteRule(Integer id) {
        Rule rule = ruleMapper.selectById(id);
        if (rule == null) {
            throw new SystemException("规则不存在");
        } else {
            ruleMapper.deleteById(id);
        }
    }

    /**
     * 修改规则
     *
     * @param rule
     */
    @Override
    public void modifyRule(Rule rule) {
        Integer id = rule.getId();
        Rule realRule = ruleMapper.selectById(id);
        if (realRule == null) {
            throw new SystemException("规则不存在");
        }
        ruleMapper.updateById(rule);
    }
}
