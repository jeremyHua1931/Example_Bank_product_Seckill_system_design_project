package com.second_kill.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName(value = "deposit_good", autoResultMap = true)
public class DepositGood implements Serializable {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private String name;
    private Double price;
    private Integer totalNumber;
    private Integer remainNumber;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date startTime;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date endTime;
    private Integer restrictNumber;
    private Double totalPrice;
    private String image;
    private Integer isFilter;
    private String description;
    @TableField(typeHandler = JacksonTypeHandler.class)
    private List<Integer> ruleList;
    private Integer status;
    @TableField(exist = false)
    private List<Rule> filterFailList;
    @TableField(exist = false)
    private String filterStatus;
    @TableField(exist = false)
    private Integer isFavor;
    @TableField(exist = false)
    private Integer isLoans;
    private Integer repeatDelay;  // 循环添加间隔
    private Integer repeatTimes;  // 循环添加次数
    private Integer totalRepeatTimes;  // 循环添加次数
}
