package com.second_kill.controller.exhandler;

import com.second_kill.entity.ResponseBean;
import com.second_kill.service.ex.ServiceException;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.HashMap;
import java.util.Map;


public class BaseController {
    public static Map<String, ResponseBean> ExceptionMap = new HashMap<>();

    static {
        ExceptionMap.put("密码错误", new ResponseBean(400, "密码错误", null));
        ExceptionMap.put("用户不存在", new ResponseBean(401, "该用户不存在", null));
        ExceptionMap.put("手机号被占用", new ResponseBean(400, "该手机号已注册", null));
        ExceptionMap.put("用户名被占用", new ResponseBean(402, "该用户名被占用", null));
        ExceptionMap.put("文件为空", new ResponseBean(600, "文件为空", null));
        ExceptionMap.put("文件格式错误", new ResponseBean(601, "文件格式错误", null));
        ExceptionMap.put("规则不存在", new ResponseBean(403, "规则不存在", null));
        ExceptionMap.put("请重新拍照", new ResponseBean(999, "请重新拍照", null));
        ExceptionMap.put("非法的手机号", new ResponseBean(400, "该手机号格式不正确", null));
        ExceptionMap.put("验证码发送过于频繁", new ResponseBean(401, "验证码发送过于频繁", null));
        ExceptionMap.put("验证码发送失败", new ResponseBean(500, "验证码发送失败,请重试", null));
        ExceptionMap.put("内部错误", new ResponseBean(500, "内部错误", null));
        ExceptionMap.put("鉴权错误", new ResponseBean(401, "鉴权错误", null));
        ExceptionMap.put("请求超时", new ResponseBean(800, "请求超时", null));
        ExceptionMap.put("不支持管理员访问", new ResponseBean(403, "不支持管理员访问", null));
    }

    //请求处理方法
    //用于统一处理抛出的异常，凡是ServiceException都会被拦截到这里
    @ExceptionHandler(ServiceException.class)
    public ResponseBean handleException(Exception e) {
        return ExceptionMap.get(e.getMessage());
    }
}
