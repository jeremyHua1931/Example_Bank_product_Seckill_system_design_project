package com.second_kill.controller;

import com.aliyun.openservices.ons.api.*;
import com.aliyun.openservices.ons.api.bean.ConsumerBean;
import com.aliyun.openservices.ons.api.bean.ProducerBean;
import com.aliyun.openservices.ons.api.bean.Subscription;
import com.aliyun.openservices.shade.com.alibaba.fastjson.JSON;
import com.aliyun.openservices.shade.com.alibaba.fastjson.JSONObject;
import com.second_kill.config.MqConfig;
import com.second_kill.config.RedisPrefix;
import com.second_kill.controller.exhandler.BaseController;
import com.second_kill.entity.MQMessage;
import com.second_kill.entity.OrderInfo;
import com.second_kill.entity.ResponseBean;
import com.second_kill.entity.payMessage;
import com.second_kill.service.IBalancePutterService;
import com.second_kill.service.IGoodOnSaleService;
import com.second_kill.service.ex.SystemException;
import com.second_kill.utils.JWTUtils;
import com.second_kill.utils.JedisUtil;
import com.second_kill.utils.Sm4Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.util.CollectionUtils;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.*;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.Transaction;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static com.second_kill.utils.JWTUtils.JWTGetUserId;
import static com.second_kill.utils.JedisUtil.getJedis;

@RestController
@RequestMapping("/client/order")
public class ClientOrderController extends BaseController {


    IGoodOnSaleService goodOnSaleService;
    IBalancePutterService balancePutterService;

    MqConfig mqConfig = new MqConfig();


    ProducerBean producer;
    Map<String, OrderInfo> LoansQueueMap = new ConcurrentHashMap<>();
    Map<String, OrderInfo> DepositQueueMap = new ConcurrentHashMap<>();
    Map<String, String> depositMd5 = new ConcurrentHashMap<>();
    Map<String, String> loansMd5 = new ConcurrentHashMap<>();

    @Autowired
    ClientOrderController(IGoodOnSaleService goodOnSaleService, ProducerBean producer, IBalancePutterService balancePutterService) {
        this.goodOnSaleService = goodOnSaleService;
        this.balancePutterService = balancePutterService;
        ConsumerBean consumer = createConsumer();
        ConsumerBean consumer2 = createConsumer();

        this.producer = producer;
        consumer.start();
        consumer2.start();
    }


    public ConsumerBean createConsumer() {
        ConsumerBean consumerBean = new ConsumerBean();
        //配置文件
        Properties properties = mqConfig.getMqPropertie();
        properties.setProperty(PropertyKeyConst.GROUP_ID, mqConfig.getGroupId());
        //将消费者线程数固定为1000个
        properties.setProperty(PropertyKeyConst.ConsumeThreadNums, "5");
        consumerBean.setProperties(properties);
        //订阅关系
        Map<Subscription, MessageListener> subscriptionTable = new HashMap<>();
        Subscription subscription = new Subscription();
        subscription.setTopic(mqConfig.getTopic());
        subscription.setExpression(mqConfig.getTag());
        subscriptionTable.put(subscription, (message, consumeContext) -> {
//            System.out.println("MSG_IGN");
//            return Action.CommitMessage;
            MQMessage _MQMessage = JSON.parseObject(new String(message.getBody()), MQMessage.class);
            if (createWork(_MQMessage.getToken(), _MQMessage.getOrderInfo()))
                return Action.CommitMessage;
            else
                return Action.ReconsumeLater;

            //return Action.CommitMessage;
        });
        //订阅多个topic如上面设置

        consumerBean.setSubscriptionTable(subscriptionTable);
        return consumerBean;
    }


    @PostMapping("/create/{MD5}")
    public ResponseBean create(@RequestHeader(value = "token") String token, @RequestBody OrderInfo order, @PathVariable String MD5) {
        Integer userId = JWTGetUserId(token);
        //校验MD5
        Jedis jedis = getJedis();
        String key = userId.toString() + "_" + order.getGoodId().toString();
        if (jedis == null) {
            throw new SystemException("内部错误");
        }
        if (order.getIsLoans()) {
            if (loansMd5.get(key) == null || !MD5.equals(loansMd5.get(key))) {
                jedis.close();
                return new ResponseBean(401, "密钥错误", null);
            }
        } else {
            if (depositMd5.get(key) == null || !MD5.equals(depositMd5.get(key))) {
                jedis.close();
                return new ResponseBean(401, "密钥错误", null);
            }
        }
        jedis.close();
        //创建消息队列消息
        order.setQueueId(goodOnSaleService.getQueueId(userId));
        MQMessage message = new MQMessage(order, token, MD5);
        Message msg = new Message("kill", "create", JSON.toJSONString(message).getBytes(StandardCharsets.UTF_8));
        try {
            producer.send(msg);
        } catch (Exception e) {
            return new ResponseBean(500, "RocketMQ网络不通畅", null);
        }

        //createWork(token,order);
        order.setNumber(null);
        order.setIsLoans(null);
        order.setGoodId(null);
        return new ResponseBean(200, "已请求订单", order);
    }

    private Boolean createWork(String token, OrderInfo order) {
        Jedis jedis = getJedis();
        if (jedis == null) {
            return false;
        }
        order.setUserId(JWTGetUserId(token));
        //创建订单（调用service）
        Integer status = 0;
        try {
            status = goodOnSaleService.createOrder(order, jedis);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //创建订单时间
        order.setCreateTime(new Date());
        //获取订单ID
        Integer orderId = order.getOrderId();

        String goodOrderKey = (order.getIsLoans() ? RedisPrefix.ORDER_LOANS : RedisPrefix.ORDER_DEPOSIT);
        String orderJson = JSON.toJSONString(order);
        if (status == 0 || status == -2) {
            //如果status为成功或部分成功，则写入order缓存
            jedis.hset(goodOrderKey, String.valueOf(orderId), orderJson);
        }
        if (order.getIsLoans()) {
            LoansQueueMap.put(order.getQueueId(), order);
        } else {
            DepositQueueMap.put(order.getQueueId(), order);
        }
        jedis.close();
        return true;
    }

    @PostMapping("/pay")
    public ResponseBean pay(@RequestHeader(value = "token") String token, @RequestBody OrderInfo order) {
        Jedis jedis = getJedis();
        if (jedis == null) {
            throw new SystemException("内部错误");
        }
        Integer userId = JWTGetUserId(token);
        JSONObject SaltAndPassword = JSON.parseObject(jedis.hget(RedisPrefix.USER_PASSWORD, String.valueOf(userId)));
        String salt = (String) SaltAndPassword.get("salt");
        String password = (String) SaltAndPassword.get("password");
        String inputPwd = order.getPassword();
        try {
            if (!Sm4Util.verifyEcb(salt, password, inputPwd)) {
                jedis.close();
                return new ResponseBean(401, "密码错误", null);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        OrderInfo realOrder = JSON.parseObject(jedis.hget(
                order.getIsLoans() ? RedisPrefix.ORDER_LOANS : RedisPrefix.ORDER_DEPOSIT,
                order.getOrderId().toString()
        ), OrderInfo.class);

        //TODO
        double price = Double.parseDouble(jedis.hget(
                (realOrder.getIsLoans() ? RedisPrefix.GOOD_LOANS_INFO : RedisPrefix.GOOD_DEPOSIT_INFO) + realOrder.getGoodId(),
                "price")) * realOrder.getNumber();

        String goodOrderKey = (order.getIsLoans() ? RedisPrefix.ORDER_LOANS : RedisPrefix.ORDER_DEPOSIT);
        switch (balancePutterService.preCostBalance(userId, -price, jedis)) {
            case -1:
                jedis.close();
                return new ResponseBean(500, "系统繁忙", null);
            case -2:
                jedis.close();
                return new ResponseBean(400, "余额不足", null);
            default:
                realOrder.setPaid(true);
                jedis.hset(goodOrderKey, String.valueOf(order.getOrderId()), JSON.toJSONString(realOrder));
                jedis.close();
                return new ResponseBean(200, "支付成功", null);
        }
    }

    @PostMapping("/check")
    public ResponseBean check(@RequestBody OrderInfo order) {
        OrderInfo realOrder;
        if (order.getIsLoans()) {
            realOrder = LoansQueueMap.get(order.getQueueId());
        } else {
            realOrder = DepositQueueMap.get(order.getQueueId());
        }
        if (realOrder == null) {
            return new ResponseBean(102, "订单查询号不存在或尚未生成", null);
        }
        switch (realOrder.getStatus()) {
            case -1:
                return new ResponseBean(200, "成功查询到订单信息", new OrderInfo(-1, "系统繁忙，请稍后再试"));
            case -3:
                return new ResponseBean(200, "成功查询到订单信息", new OrderInfo(-3, "商品已售罄"));
            case -4:
                return new ResponseBean(200, "成功查询到订单信息", new OrderInfo(-4, "您的购买数量超过限制"));
            case -5:
                return new ResponseBean(200, "成功查询到订单信息", new OrderInfo(-5, "初筛未通过"));
        }
        realOrder.setQueueId(null);
        realOrder.setGoodId(null);
        realOrder.setUserId(null);
        realOrder.setIsLoans(null);
        return new ResponseBean(200, "创建订单成功", realOrder);
    }

    @GetMapping("/getMd5Deposit")
    public ResponseBean getMd5Deposit(@RequestHeader(value = "token") String token, Integer goodId) {
        Jedis jedis = JedisUtil.getJedis();
        assert jedis != null;
        Integer userId = JWTGetUserId(token);
        String key = userId.toString() + "_" + goodId.toString();
        if (!goodOnSaleService.isGoodInSale(false, goodId, jedis)) {
            jedis.close();
            return new ResponseBean(404, "秒杀不存在或未开始", null);
        }
        jedis.close();
        if (depositMd5.get(key) != null) {
            return new ResponseBean(200, "获取成功", depositMd5.get(key));
        }
        String value = DigestUtils.md5DigestAsHex((userId + goodId + new Date().toString()).getBytes());
        depositMd5.put(key, value);
        return new ResponseBean(200, "获取成功", value);
    }

    @GetMapping("/getMd5Loans")
    public ResponseBean getMd5Loans(@RequestHeader(value = "token") String token, Integer goodId) {
        Jedis jedis = JedisUtil.getJedis();
        assert jedis != null;
        Integer userId = JWTGetUserId(token);
        String key = userId.toString() + "_" + goodId.toString();
        if (!goodOnSaleService.isGoodInSale(true, goodId, jedis)) {
            jedis.close();
            return new ResponseBean(404, "秒杀不存在或未开始", null);
        }
        jedis.close();
        if (loansMd5.get(key) != null) {
            return new ResponseBean(200, "获取成功", loansMd5.get(key));
        }
        String value = DigestUtils.md5DigestAsHex((userId + goodId + new Date().toString()).getBytes());
        loansMd5.put(key, value);
        return new ResponseBean(200, "获取成功", value);
    }

    @PostMapping("/refund")
    public ResponseBean refund(@RequestHeader(value = "token") String token, @RequestBody OrderInfo order) {
        switch (goodOnSaleService.payBackOrder(order, JWTUtils.JWTGetUserId(token))) {
            case -1:
                return new ResponseBean(500, "系统繁忙", null);
            case -2:
                return new ResponseBean(400, "未找到", null);
            case -3:
                return new ResponseBean(400, "正在处理订单", null);
            default:
                return new ResponseBean(200, "退款处理成功", null);
        }

    }

    /**
     * 定时删除queueID
     */
    @Scheduled(cron = "0 */1 * * * ?")
    public void deleteQueue() {

        for (String key : LoansQueueMap.keySet()) {
            OrderInfo orderInfo = LoansQueueMap.get(key);
            long expireTime = orderInfo.getCreateTime().getTime() + 900000;
            long time = new Date().getTime();
            if (time > expireTime) {
                LoansQueueMap.remove(key);
            }
        }

        for (String key : DepositQueueMap.keySet()) {
            OrderInfo orderInfo = DepositQueueMap.get(key);
            long expireTime = orderInfo.getCreateTime().getTime() + 900000;
            long time = new Date().getTime();
            if (time > expireTime) {
                DepositQueueMap.remove(key);
            }
        }

    }

}
