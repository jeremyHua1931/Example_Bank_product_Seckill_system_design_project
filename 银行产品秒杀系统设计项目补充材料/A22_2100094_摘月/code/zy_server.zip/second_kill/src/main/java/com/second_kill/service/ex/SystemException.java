package com.second_kill.service.ex;

/**
 * 自定义异常(CustomException)
 *
 * @author dolyw.com
 * @date 2018/8/30 13:59
 */
public class SystemException extends ServiceException {

    public SystemException(String msg) {
        super(msg);
    }

    public SystemException() {
        super();
    }
}
