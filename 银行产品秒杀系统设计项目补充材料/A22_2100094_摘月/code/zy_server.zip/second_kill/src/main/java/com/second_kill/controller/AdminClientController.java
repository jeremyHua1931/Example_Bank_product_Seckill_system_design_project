package com.second_kill.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.second_kill.controller.exhandler.BaseController;
import com.second_kill.entity.*;
import com.second_kill.mapper.IClientMapper;
import com.second_kill.service.*;
import com.second_kill.service.ex.SystemException;
import com.second_kill.utils.StringUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin/client")
@Transactional
public class AdminClientController extends BaseController {

    //存放驱动变量名
    private static final List<String> attribute = new ArrayList<>();
    private final IClientService clientService;
    private final IAdminService adminService;
    private final IDepositResultService depositResultService;
    private final ILoansResultService loansResultService;
    private final IClientMapper clientMapper;
    @Autowired
    IPreFilterService preFilterService;

    @Autowired
    AdminClientController(IClientService clientService, IAdminService adminService, IDepositResultService depositResultService
            , ILoansResultService loansResultService, IClientMapper clientMapper) {
        this.clientService = clientService;
        this.adminService = adminService;
        this.depositResultService = depositResultService;
        this.loansResultService = loansResultService;
        this.clientMapper = clientMapper;
    }

    /**
     * 获取用户列表
     *
     * @param page     第几页
     * @param size     一共多少页
     * @param username
     * @param phone
     * @return
     */
    @GetMapping("/userList")
    public ResponseBean getUserList(Integer page, Integer size, @Nullable String username, @Nullable String phone) {
        Map<String, Object> data = new HashMap<>();
        QueryWrapper<Client> queryWrapper = new QueryWrapper<>();
        List<Client> userList = new ArrayList<>();
        if (StringUtil.isBlank(username) && StringUtil.isBlank(phone)) {
            Page<Client> UserPage = new Page<>(page, size);
            Page<Client> pages = clientService.page(UserPage);
            List<Client> records = pages.getRecords();
            long count = UserPage.getTotal();
            //将不用的数据隐藏
            for (Client client : records) {
                client.setPassword(null);
                client.setSalt(null);
                userList.add(client);
            }
            data.put("count", count);
            data.put("userList", userList);
            return new ResponseBean(200, "查询成功", data);
        } else {
            if (!StringUtil.isBlank(username) && StringUtil.isBlank(phone)) {
                queryWrapper.like("username", username);
            } else if (StringUtil.isBlank(username)) {
                queryWrapper.like("phone", phone);
            } else {
                Map<String, String> map = new HashMap<>();
                map.put("phone", phone);
                map.put("username", username);
                queryWrapper.allEq(map);
            }
        }
        IPage<Client> pages = new Page<>(page, size);
        pages = clientService.getBaseMapper().selectPage(pages, queryWrapper);
        List<Client> records = pages.getRecords();
        long count = records.size();
        //将不用的数据隐藏
        for (Client client : records) {
            client.setPassword(null);
            client.setSalt(null);
            userList.add(client);
        }
        data.put("count", count);
        data.put("userList", records);
        return new ResponseBean(200, "返回成功", data);
    }

    /**
     * 删除管理员
     *
     * @param id 管理员id
     * @return
     */
    @DeleteMapping("/delete")
    public ResponseBean delete(Integer id) {
        adminService.deleteClient(id);
        return new ResponseBean(200, "删除成功", null);
    }

    /**
     * 获取存款初筛结果
     *
     * @param goodId
     * @param page
     * @param size
     * @return
     */
    @GetMapping("/depositFilterResult")
    public ResponseBean depositFilterResult(Integer id, Integer page, Integer size) {
        List<DepositResult> depositResults = depositResultService.depositFilterResult(id, page, size);
        depositResults.forEach((e) -> {
            e.setReason(JSON.parseArray(e.getReasonStr()).toJavaList(Rule.class));
            e.setReasonStr(null);
        });
        QueryWrapper<DepositResult> depositResultQueryWrapper = new QueryWrapper<>();
        depositResultQueryWrapper.eq("good_id", id);
        Long count = depositResultService.getBaseMapper().selectCount(depositResultQueryWrapper);
        Map<String, Object> data = new HashMap<>();
        data.put("resultList", depositResults);
        data.put("count", count);
        return new ResponseBean(200, "查询成功", data);
    }

    /**
     * 获取贷款初筛结果
     *
     * @param id
     * @param page
     * @param size
     * @return
     */
    @GetMapping("/loanFilterResult")
    public ResponseBean loanFilterResult(Integer id, Integer page, Integer size) {
        List<LoansResult> loansResults = loansResultService.loansFilterResult(id, page, size);
        loansResults.forEach((e) -> {
            e.setReason(JSON.parseArray(e.getReasonStr()).toJavaList(Rule.class));
            e.setReasonStr(null);
        });
        QueryWrapper<LoansResult> loansResultQueryWrapper = new QueryWrapper<>();
        loansResultQueryWrapper.eq("good_id", id);
        Long count = loansResultService.getBaseMapper().selectCount(loansResultQueryWrapper);
        Map<String, Object> data = new HashMap<>();
        data.put("resultList", loansResults);
        data.put("count", count);
        return new ResponseBean(200, "查询成功", data);
    }

    /**
     * 上传驱动变量的Excel文件
     *
     * @param file
     * @return
     * @throws IOException
     */
    @PostMapping("/userAttribute")
    public ResponseBean userAttribute(MultipartFile file) throws IOException {
        attribute.clear();  //每次调用需要清空attribute,否则会
        if (file == null) {
            throw new SystemException("文件为空");
        }
        String oldFileName = file.getOriginalFilename();
        assert oldFileName != null;
        String eName = oldFileName.substring(oldFileName.lastIndexOf("."));
        if (!eName.equals(".xls") && !eName.equals(".xlsx")) {
            throw new SystemException("文件格式错误");
        }
        Workbook attributeExcel = null;
        InputStream inputStream = file.getInputStream();
        if (eName.equals(".xls")) {
            attributeExcel = new HSSFWorkbook(inputStream);
        } else {
            attributeExcel = new XSSFWorkbook(inputStream);
        }
        //获取工作表
        Sheet sheet = attributeExcel.getSheetAt(0);
        Row row = sheet.getRow(0);
        int i = 1;
        //读取驱动变量并且存入attribute列表
        while (row.getCell(i) != null) {
            if (!StringUtil.isBlank(row.getCell(i).getStringCellValue())) {
                attribute.add(row.getCell(i).getStringCellValue());
                i++;
            }
        }
        int index = 1;
        //将驱动变量的名称与值放到Map中
        while (sheet.getRow(index) != null) {
            Row infoRow = sheet.getRow(index);
            Map<String, String> variable = new HashMap<>();
            variable.put("username", infoRow.getCell(0).getStringCellValue());
            for (int k = 0; ; k++) {
                Cell cell = infoRow.getCell(k + 1);
                if (cell == null) {
                    cell = infoRow.createCell(k, CellType.STRING);
                    cell.setCellValue("");
                }
                cell.setCellType(CellType.STRING);
                if (StringUtil.isBlank(cell.getStringCellValue()) && k + 1 <= attribute.size()) {
                    Map<String, Object> data = new HashMap<>();
                    data.put("row", index + 1);
                    data.put("column", (char) (k + 66) + "");
                    return new ResponseBean(600, "文件中有空缺", data);
                }
                if (infoRow.getCell(k + 1) == null) {
                    break;
                }
                if (cell.getStringCellValue() == null) {
                    break;
                }
                variable.put(attribute.get(k), cell.getStringCellValue());
            }
            com.alibaba.fastjson.JSONObject json = JSONObject.parseObject(JSON.toJSONString(variable)); //将map转为fastjson格式
            QueryWrapper<Client> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("username", infoRow.getCell(0).getStringCellValue());
            Client client = clientService.getBaseMapper().selectOne(queryWrapper);
            if (client == null) {
                Map<String, Integer> data = new HashMap<>();
                data.put("row", index + 1);  //告知前端第几行的用户名不存在
                return new ResponseBean(400, "文件中的用户名不存在", data);
            }
            client.setAttribute(json);
            clientService.getBaseMapper().updateById(client);
            index++;
        }

        preFilterService.updateAllFilter();

        return new ResponseBean(200, "上传成功", null);
    }

    @GetMapping("/download")
    public void download(HttpServletResponse response) throws IOException {
        String codedFileName = "template";
        response.setHeader("Content-Disposition", "attachment;filename=" + codedFileName + ".xlsx");
        // 响应类型,编码
        response.setContentType("application/vnd.ms-excel;charset=UTF-8");
        // 形成输出流
        OutputStream osOut = response.getOutputStream();
        BufferedOutputStream bufferedOutPut = new BufferedOutputStream(osOut);
        bufferedOutPut.flush();
        FileInputStream inputStream = new FileInputStream("/Users/zhengjunyuan/Desktop/template.xlsx");
        try {
            XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
            Sheet sheet = workbook.getSheetAt(0);
            List<String> usernameList = clientMapper.selectUsername();
            int index = 1;
            Row row;
            Cell cell;
            for (String s : usernameList) {
                row = sheet.createRow(index);
                cell = row.createCell(0);
                cell.setCellValue(s);
                index++;
            }
            workbook.write(bufferedOutPut);
        } catch (Exception e){
            e.printStackTrace();
        } finally {
            osOut.close();
        }
    }
}
