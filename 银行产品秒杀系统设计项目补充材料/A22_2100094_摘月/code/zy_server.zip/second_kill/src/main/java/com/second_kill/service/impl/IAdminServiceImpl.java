package com.second_kill.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.second_kill.entity.Admin;
import com.second_kill.entity.Client;
import com.second_kill.mapper.IAdminMapper;
import com.second_kill.mapper.IClientMapper;
import com.second_kill.service.IAdminService;
import com.second_kill.service.ex.SystemException;
import com.second_kill.utils.Sm4Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import java.util.Date;
import java.util.UUID;
import java.util.regex.Pattern;

@Service
public class IAdminServiceImpl extends ServiceImpl<IAdminMapper, Admin> implements IAdminService {
    @Autowired
    IAdminMapper adminMapper;

    @Autowired
    IClientMapper clientMapper;

    /**
     * 添加管理员
     *
     * @param admin 管理员信息
     */
    @Override
    public Admin addAdmin(Admin admin) throws Exception {
        QueryWrapper<Admin> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("phone", admin.getPhone());
        Long count = adminMapper.selectCount(queryWrapper);
        if (count > 0) {
            throw new SystemException("手机号被占用");
        }
        QueryWrapper<Admin> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("username", admin.getPhone());
        Long count1 = adminMapper.selectCount(queryWrapper1);
        if (count1 > 0) {
            throw new SystemException("用户名被占用");
        }
        String salt = Sm4Util.generateHexString();
        String Sm4Password = null;
        Sm4Password = Sm4Util.encryptEcb(salt, admin.getPassword());
        Admin adm = new Admin();
        adm.setAvatar(admin.getAvatar());
        adm.setCreateTime(new Date());
        adm.setUsername(admin.getUsername());
        adm.setPhone(admin.getPhone());
        adm.setName(admin.getName());
        adm.setSalt(salt);
        adm.setPassword(Sm4Password);
        adminMapper.insert(adm);
        return adm;
    }

    @Override
    public Admin login(String pOrU, String password) throws Exception {
        Admin realAdmin = getUserByPOrU(pOrU);
        if (realAdmin == null) {
            throw new SystemException("用户不存在");
        }
        String Sm4Password = realAdmin.getPassword(); //数据库中的Sm4密码
        String salt = realAdmin.getSalt(); //数据库中的salt

        if (!Sm4Util.verifyEcb(salt, Sm4Password, password)) {
            throw new SystemException("密码错误");
        }
        return realAdmin;
    }

    /**
     * 删除管理员
     *
     * @param id 管理员id
     */
    @Override
    public void deleteAdmin(Integer id) {
        Admin admin = adminMapper.selectById(id);
        if (admin == null) {
            throw new SystemException("该用户不存在");
        } else {
            adminMapper.deleteById(id);
        }
    }

    /**
     * 获取管理员信息
     *
     * @param id 管理员id
     * @return
     */
    @Override
    public Admin getInfo(Integer id) {
        Admin admin = adminMapper.selectById(id);
        if (admin == null) {
            throw new SystemException("该用户不存在");
        } else {
            return admin;
        }
    }

    @Override
    public Admin getInfoNoPwd(Integer id) {
        return null;
    }

    /**
     * 更新管理员信息
     *
     * @param id
     * @param username
     * @param avatar
     */
    @Override
    public void updateInfo(Integer id, String username, String avatar, String password, String name, String phone) throws Exception{
        QueryWrapper<Admin> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        queryWrapper.ne("id", id);
        Long count = adminMapper.selectCount(queryWrapper);
        if (count > 0) {
            throw new SystemException("用户名被占用");
        }
        QueryWrapper<Admin> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("phone", phone);
        queryWrapper1.ne("id", id);
        count = adminMapper.selectCount(queryWrapper1);
        if (count > 0) {
            throw new SystemException("手机号被占用");
        }
        Admin realAdmin = adminMapper.selectById(id);
        String salt = realAdmin.getSalt();
        String newPassword = null;
        newPassword = Sm4Util.decryptEcb(salt, password);
        Admin admin = adminMapper.selectById(id);
        admin.setPassword(newPassword);
        admin.setUsername(username);
        admin.setPhone(phone);
        admin.setName(name);
        admin.setAvatar(avatar);
        adminMapper.updateById(admin);
    }

    /**
     * 删除客户
     *
     * @param id
     */
    @Override
    public void deleteClient(Integer id) {
        Client client = clientMapper.selectById(id);
        if (client == null) {
            throw new SystemException("用户不存在");
        }
        clientMapper.deleteById(id);
    }

    /**
     * 判读输入的是手机号还是用户名
     *
     * @param pOrU 手机号或者用户名
     * @return
     */
    private Admin getUserByPOrU(String pOrU) {
        QueryWrapper<Admin> queryWrapper = new QueryWrapper<>();
        if (Pattern.matches("^1[3-9]\\d{9}$", pOrU)) {
            queryWrapper.eq("phone", pOrU);
        } else {
            queryWrapper.eq("username", pOrU);
        }

        return adminMapper.selectOne(queryWrapper); //查询数据库中的用户信息
    }

}
