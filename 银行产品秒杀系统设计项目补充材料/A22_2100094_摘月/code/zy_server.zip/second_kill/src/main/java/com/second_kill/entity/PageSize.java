package com.second_kill.entity;


import lombok.Data;

@Data
public class PageSize {
    private Integer page;
    private Integer size;
}
