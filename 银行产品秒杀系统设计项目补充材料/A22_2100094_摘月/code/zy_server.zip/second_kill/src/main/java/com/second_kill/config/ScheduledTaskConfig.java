package com.second_kill.config;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.second_kill.entity.*;
import com.second_kill.mapper.*;
import com.second_kill.service.*;
import com.second_kill.utils.GoodStatusUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static com.second_kill.utils.JedisUtil.getJedis;
import static com.second_kill.utils.baidu.TimeUtil.getMonthDayStr;

@Component
@EnableAsync
public class ScheduledTaskConfig {
    private final IClientService clientService;
    private final IDepositsGoodService depositsGoodService;
    private final ILoansGoodService loansGoodService;
    private final IRuleService ruleService;
    private final IPreFilterService preFilterService;
    private final IGoodOnSaleService goodOnSaleService;
    private final IClientMapper clientMapper;
    private final IDepositMapper depositMapper;
    private final ILoansMapper loansMapper;
    private final IDepositOrderMapper depositOrderMapper;
    private final ILoansOrderMapper loansOrderMapper;
    private final ILoansResultService loansResultService;
    private final IDepositResultService depositResultService;

    @Autowired
    ScheduledTaskConfig(
            IClientService clientService,
            IDepositsGoodService iDepositsGoodService,
            ILoansGoodService iLoansGoodService,
            IRuleService ruleService,
            IPreFilterService preFilterService,
            IGoodOnSaleService goodOnSaleService,
            IClientMapper clientMapper,
            IDepositMapper depositMapper, ILoansMapper loansMapper, IDepositOrderMapper depositOrderMapper, ILoansOrderMapper loansOrderMapper, ILoansResultService loansResultService, IDepositResultService depositResultService) {
        this.clientMapper = clientMapper;
        this.clientService = clientService;
        this.depositsGoodService = iDepositsGoodService;
        this.loansGoodService = iLoansGoodService;
        this.ruleService = ruleService;
        this.preFilterService = preFilterService;
        this.goodOnSaleService = goodOnSaleService;
        this.depositMapper = depositMapper;
        this.loansMapper = loansMapper;
        this.depositOrderMapper = depositOrderMapper;
        this.loansOrderMapper = loansOrderMapper;
        this.loansResultService = loansResultService;
        this.depositResultService = depositResultService;

    }
    private final ConcurrentHashMap isRunning = new ConcurrentHashMap();


    @Scheduled(fixedDelay = 30000)
    @Async("dataProcessExecutor")
    public void persistenceLoop() {
        if("running".equals(isRunning.get("1")))return;
        isRunning.put("1","running");
        System.out.println("持久化进程开始[线程运行于:"+Thread.currentThread().getName()+"#"+Thread.currentThread().getId()+"]");
        Jedis jedis = getJedis();
        assert jedis != null;
        //持久化用户余额
        Map<String, String> userData = jedis.hgetAll(RedisPrefix.USER_PASSWORD);
        for (String id : userData.keySet()) {
            try {
                if(id.equals("0")){
                    clientMapper.updateBalance(0, goodOnSaleService.getCompanyAccount());
                }else {
                    try{
                        Double balance = Double.valueOf(jedis.hget(RedisPrefix.USER_DATA + id, "balance"));
                        clientMapper.updateBalance(Integer.valueOf(id), balance);
                    }catch (Exception e) {
                        System.out.println("don't care");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //持久化存款商品剩余数量
        List<Integer> DepositIdList = depositMapper.getIdList();
        for (Integer integer : DepositIdList) {
            try {
                String key = RedisPrefix.GOOD_DEPOSIT_INFO + integer.toString();
                if (!jedis.exists(key)) {
                    continue;
                } else {
                    Integer remain = Integer.valueOf(jedis.hget(key, "remain"));
                    depositMapper.updateRemain(integer, remain);
                    loansMapper.updateStatus(integer, GoodStatusUtil.getStatus(
                            new Date(Long.parseLong(jedis.hget(key, "startTime"))),
                            new Date(Long.parseLong(jedis.hget(key, "endTime")))
                    ));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //持久化贷款商品剩余数量
        List<Integer> LoansIdList = loansMapper.getIdList();
        for (Integer integer : LoansIdList) {
            try {
                String key = RedisPrefix.GOOD_LOANS_INFO + integer.toString();
                if (!jedis.exists(key)) {
                    continue;
                } else {
                    Integer remain = Integer.valueOf(jedis.hget(key, "remain"));
                    loansMapper.updateRemain(integer, remain);
                    loansMapper.updateStatus(integer, GoodStatusUtil.getStatus(
                            new Date(Long.parseLong(jedis.hget(key, "startTime"))),
                            new Date(Long.parseLong(jedis.hget(key, "endTime")))
                    ));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //持久化存款订单
        if (jedis.exists(RedisPrefix.ORDER_DEPOSIT)) {
            Map<String, String> depositOrder = jedis.hgetAll(RedisPrefix.ORDER_DEPOSIT);
            for (String key : depositOrder.keySet()) {
                try {
                    JSONObject json = JSONObject.parseObject(jedis.hget(RedisPrefix.ORDER_DEPOSIT, key));
                    if (!json.getBoolean("paid")) {
                        continue;
                    }
                    Integer goodId = (Integer) json.get("goodId");
                    Integer orderId = (Integer) json.get("orderId");
                    Integer userId = (Integer) json.get("userId");
                    Integer number = (Integer) json.get("number");
                    Integer status = 1;// (Integer) json.get("status");
                    Double totalPrice = json.getDouble("totalPrice");
                    String goodName = (String) json.get("name");
                    String redisTime = String.valueOf(json.get("createTime"));
                    Date date = new Date(Long.parseLong(redisTime));
                    DepositOrder order = new DepositOrder();
                    order.setGoodId(goodId);
                    order.setCreateTime(date);
                    order.setId(orderId);
                    order.setUserId(userId);
                    order.setStatus(status);
                    order.setNumber(number);
                    order.setTotalPrice(totalPrice);
                    order.setName(goodName);
                    depositOrderMapper.insert(order);
                    jedis.hdel(RedisPrefix.ORDER_DEPOSIT, key);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        //持久化贷款订单
        if (jedis.exists(RedisPrefix.ORDER_LOANS)) {
            Map<String, String> loansOrder = jedis.hgetAll(RedisPrefix.ORDER_LOANS);
            for (String key : loansOrder.keySet()) {
                try {
                    JSONObject json = JSONObject.parseObject(jedis.hget(RedisPrefix.ORDER_LOANS, key));
                    if (!json.getBoolean("paid")) {
                        continue;
                    }
                    Integer goodId = (Integer) json.get("goodId");
                    Integer orderId = (Integer) json.get("orderId");
                    Integer userId = (Integer) json.get("userId");
                    Integer number = (Integer) json.get("number");
                    Integer status = 1;//(Integer) json.get("status");
                    Double totalPrice = json.getDouble("totalPrice");
                    String goodName = (String) json.get("name");
                    String redisTime = String.valueOf(json.get("createTime"));
                    Date date = new Date(Long.parseLong(redisTime));
                    LoansOrder order = new LoansOrder();
                    order.setGoodId(goodId);
                    order.setCreateTime(date);
                    order.setId(orderId);
                    order.setUserId(userId);
                    order.setStatus(status);
                    order.setNumber(number);
                    order.setTotalPrice(totalPrice);
                    order.setName(goodName);
                    loansOrderMapper.insert(order);
                    jedis.hdel(RedisPrefix.ORDER_LOANS, key);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        if (jedis.exists(RedisPrefix.FILTER_LOG_LOANS)) {
            Long len = jedis.llen(RedisPrefix.FILTER_LOG_LOANS);
            for (int i = 0; i < len; i++) {
                try {
                    JSONObject json = JSONObject.parseObject(jedis.lpop(RedisPrefix.FILTER_LOG_LOANS));
                    LoansResult filterRes = new LoansResult();

                    Integer goodId = json.getInteger("goodId");
                    Integer userId = json.getInteger("userId");
                    String result = json.getString("result");
                    Date createTime = json.getDate("createTime");
                    List<Rule> reason = json.getJSONArray("reason").toJavaList(Rule.class);

                    filterRes.setCreateTime(createTime);
                    filterRes.setGoodId(goodId);
                    filterRes.setUserId(userId);
                    filterRes.setReason(reason);
                    switch (result) {
                        case "passed":
                            filterRes.setResult(1);
                            break;
                        case "rejected":
                            filterRes.setResult(0);
                            break;
                        case "notFinished":
                            filterRes.setResult(2);
                            break;
                        case "notFound":
                            filterRes.setResult(3);
                            break;
                    }
                    loansResultService.getBaseMapper().insert(filterRes);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        if (jedis.exists(RedisPrefix.FILTER_LOG_DEPOSIT)) {
            Long len = jedis.llen(RedisPrefix.FILTER_LOG_DEPOSIT);
            for (int i = 0; i < len; i++) {
                try {
                    JSONObject json = JSONObject.parseObject(jedis.lpop(RedisPrefix.FILTER_LOG_DEPOSIT));
                    DepositResult filterRes = new DepositResult();

                    Integer goodId = json.getInteger("goodId");
                    Integer userId = json.getInteger("userId");
                    String result = json.getString("result");
                    Date createTime = json.getDate("createTime");
                    List<Rule> reason = json.getJSONArray("reason").toJavaList(Rule.class);

                    filterRes.setGoodId(goodId);
                    filterRes.setUserId(userId);
                    filterRes.setReason(reason);
                    filterRes.setCreateTime(createTime);
                    switch (result) {
                        case "passed":
                            filterRes.setResult(1);
                            break;
                        case "rejected":
                            filterRes.setResult(0);
                            break;
                        case "notFinished":
                            filterRes.setResult(2);
                            break;
                        case "notFound":
                            filterRes.setResult(3);
                            break;
                    }
                    depositResultService.getBaseMapper().insert(filterRes);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        //退款单回存数据库
        if (jedis.exists(RedisPrefix.ORDER_DEPOSIT_REFUND)) {
            Map<String, String> depositOrder = jedis.hgetAll(RedisPrefix.ORDER_DEPOSIT_REFUND);
            depositOrder.forEach((k, v) -> {
                try {
                    if (v.equals("processing")) return;
                    OrderInfo orderInfo = JSON.parseObject(v, OrderInfo.class);
                    if (orderInfo.getPaid()) {
                        QueryWrapper<DepositOrder> qw = new QueryWrapper<>();
                        qw.eq("id", orderInfo.getOrderId());
                        if (orderInfo.getStatus() == -2) {
                            depositOrderMapper.delete(qw);
                            return;
                        }
                        DepositOrder order = new DepositOrder();
                        order.setGoodId(orderInfo.getGoodId());
                        order.setCreateTime(orderInfo.getCreateTime());
                        order.setId(orderInfo.getOrderId());
                        order.setUserId(orderInfo.getUserId());
                        order.setStatus(orderInfo.getStatus());
                        order.setNumber(orderInfo.getNumber());
                        if (depositOrderMapper.exists(qw)) {
                            depositOrderMapper.updateById(order);
                        } else {
                            depositOrderMapper.insert(order);
                        }
                    } else {
                        jedis.hset(RedisPrefix.ORDER_DEPOSIT, String.valueOf(orderInfo.getOrderId()), v);
                    }
                    jedis.hdel(RedisPrefix.ORDER_DEPOSIT_REFUND, k);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        }
        //退款单回存数据库
        if (jedis.exists(RedisPrefix.ORDER_LOANS_REFUND)) {
            Map<String, String> depositOrder = jedis.hgetAll(RedisPrefix.ORDER_LOANS_REFUND);
            depositOrder.forEach((k, v) -> {
                try {
                    if (v.equals("processing")) return;
                    OrderInfo orderInfo = JSON.parseObject(v, OrderInfo.class);
                    if (orderInfo.getPaid()) {
                        QueryWrapper<LoansOrder> qw = new QueryWrapper<>();
                        qw.eq("id", orderInfo.getOrderId());
                        if (orderInfo.getStatus() == -2) {
                            loansOrderMapper.delete(qw);
                            return;
                        }
                        LoansOrder order = new LoansOrder();
                        order.setGoodId(orderInfo.getGoodId());
                        order.setCreateTime(orderInfo.getCreateTime());
                        order.setId(orderInfo.getOrderId());
                        order.setUserId(orderInfo.getUserId());
                        order.setStatus(orderInfo.getStatus());
                        order.setNumber(orderInfo.getNumber());
                        if (loansOrderMapper.exists(qw)) {
                            loansOrderMapper.updateById(order);
                        } else {
                            loansOrderMapper.insert(order);
                        }
                    } else {
                        jedis.hset(RedisPrefix.ORDER_LOANS, String.valueOf(orderInfo.getOrderId()), v);
                    }
                    jedis.hdel(RedisPrefix.ORDER_LOANS_REFUND, k);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        }
        jedis.close();
        isRunning.put("1","ended");
        System.out.println("持久化进程结束[线程运行于:"+Thread.currentThread().getName()+"#"+Thread.currentThread().getId()+"]");
    }


    @Scheduled(fixedRate = 30000)
    @Async("dataProcessExecutor")
    public void checkNearStart() {
        if("running".equals(isRunning.get("2")))return;
        isRunning.put("2","running");
        System.out.println("商品初始化检查开始[线程运行于:"+Thread.currentThread().getName()+"#"+Thread.currentThread().getId()+"]");
        Jedis jedis = getJedis();
        assert jedis != null;
        loansGoodService.getBaseMapper().selectList(new QueryWrapper<>()).forEach((good) -> {
            try {
                if (good.getStartTime().getTime() > System.currentTimeMillis() + 600000) {
                    return;
                }
                if (!jedis.exists(RedisPrefix.GOOD_LOANS_INFO + good.getId().toString())) {
                    goodOnSaleService.initGoodInfo(good);
                }
                if (!preFilterService.hasFiltered(true, good.getId()))
                    preFilterService.updateFilterLoans(good);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        depositsGoodService.getBaseMapper().selectList(new QueryWrapper<>()).forEach((good) -> {
            try {
                if (good.getStartTime().getTime() > System.currentTimeMillis() + 600000) { // 如果离开始时间还有10分钟多，则不开始初始化信息。
                    return;
                }
                if (!jedis.exists(RedisPrefix.GOOD_DEPOSIT_INFO + good.getId().toString())) {  // 开始秒杀前10分钟，开始往redis加入商品信息。
                    goodOnSaleService.initGoodInfo(good);
                }
                if (!preFilterService.hasFiltered(false, good.getId()))
                    preFilterService.updateFilterDeposit(good);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        jedis.close();
        isRunning.put("2","ended");
        System.out.println("商品初始化检查结束[线程运行于:"+Thread.currentThread().getName()+"#"+Thread.currentThread().getId()+"]");
    }

    @Scheduled(cron = "0 0 0 * * *")
    public void createKey() {
        Jedis jedis = getJedis();
        assert jedis != null;
        String monthDayStr = getMonthDayStr();
        jedis.hset(RedisPrefix.VISITS, monthDayStr, "0");
        jedis.hset(RedisPrefix.NEW_USER, monthDayStr, "0");
        jedis.hset(RedisPrefix.AMOUNT_LOANS, monthDayStr, "0");
        jedis.hset(RedisPrefix.AMOUNT_DEPOSIT, monthDayStr, "0");
        jedis.hset(RedisPrefix.ORDER_NUMBER, monthDayStr, "0");
        jedis.close();
    }

    /**
     * 删除活动结束的商品信息，并且更新redis的开始时间、结束时间、更新循环次数
     * 方便下一次秒杀的开始
     */

    @Scheduled(cron = "0 */1 * * * ?")
    @Async("dataProcessExecutor")
    public void deleteGoods() {
        if("running".equals(isRunning.get("3")))return;
        isRunning.put("3","running");
        System.out.println("商品结束检查开始[线程运行于:"+Thread.currentThread().getName()+"#"+Thread.currentThread().getId()+"]");
        Jedis jedis = getJedis();
        assert jedis != null;
        {
            List<Integer> idList = depositMapper.getIdList();
            int size = idList.size();
            for (int i = 0; i < size; i++) {
                if (jedis.exists(RedisPrefix.GOOD_DEPOSIT_INFO + i)) {
                    if (System.currentTimeMillis() > Long.parseLong(jedis.hget(RedisPrefix.GOOD_DEPOSIT_INFO + i, "endTime"))) {
                        int repeatTimes;
                        repeatTimes = Integer.parseInt(jedis.hget(RedisPrefix.GOOD_DEPOSIT_INFO + i, "repeatTimes"));
                        if (repeatTimes > 0) { //判断剩余的重复次数
                            repeatTimes--;
                            jedis.hset(RedisPrefix.GOOD_DEPOSIT_INFO + i, "repeatTimes", Integer.toString(repeatTimes));

                            long startTime = Long.parseLong(jedis.hget(RedisPrefix.GOOD_DEPOSIT_INFO + i, "startTime"));
                            long endTime = Long.parseLong(jedis.hget(RedisPrefix.GOOD_DEPOSIT_INFO + i, "endTime"));

                            startTime = startTime + Long.parseLong(jedis.hget(RedisPrefix.GOOD_DEPOSIT_INFO + i, "repeatDelay")) * 86400000;
                            endTime = endTime + Long.parseLong(jedis.hget(RedisPrefix.GOOD_DEPOSIT_INFO + i, "repeatDelay")) * 86400000;

                            jedis.hset(RedisPrefix.GOOD_DEPOSIT_INFO + i, "startTime", Long.toString(startTime));
                            jedis.hset(RedisPrefix.GOOD_DEPOSIT_INFO + i, "endTime", Long.toString(endTime));
                            //存入MySQL
                            DepositGood depositGood = depositsGoodService.getBaseMapper().selectById(i);
                            depositGood.setEndTime(new Date(endTime));
                            depositGood.setStartTime(new Date(startTime));
                            depositGood.setRepeatTimes(repeatTimes);
                            depositGood.setStatus(0);
                            depositsGoodService.getBaseMapper().updateById(depositGood);
                        } else {
                            jedis.del(RedisPrefix.GOOD_DEPOSIT_INFO + i);
                            DepositGood depositGood = depositsGoodService.getBaseMapper().selectById(i);
                            depositGood.setStatus(2);
                            depositsGoodService.getBaseMapper().updateById(depositGood);
                        }
                    }
                }
            }
        }
        {
            List<Integer> idList = loansMapper.getIdList();
            int size = idList.size();
            for (int i = 0; i < size; i++) {
                if (jedis.exists(RedisPrefix.GOOD_LOANS_INFO + i)) {
                    if (System.currentTimeMillis() > Long.parseLong(jedis.hget(RedisPrefix.GOOD_LOANS_INFO + i, "endTime"))) {
                        int repeatTimes;
                        repeatTimes = Integer.parseInt(jedis.hget(RedisPrefix.GOOD_LOANS_INFO + i, "repeatTimes"));
                        if (repeatTimes > 0) { //判断剩余的重复次数
                            repeatTimes--;
                            jedis.hset(RedisPrefix.GOOD_LOANS_INFO + i, "repeatTimes", Integer.toString(repeatTimes));
                            long startTime = Long.parseLong(jedis.hget(RedisPrefix.GOOD_LOANS_INFO + i, "startTime"));
                            long endTime = Long.parseLong(jedis.hget(RedisPrefix.GOOD_LOANS_INFO + i, "endTime"));
                            startTime = startTime + Long.parseLong(jedis.hget(RedisPrefix.GOOD_LOANS_INFO + i, "repeatDelay")) * 86400000;
                            endTime = endTime + Long.parseLong(jedis.hget(RedisPrefix.GOOD_LOANS_INFO + i, "repeatDelay")) * 86400000;
                            jedis.hset(RedisPrefix.GOOD_LOANS_INFO + i, "startTime", Long.toString(startTime));
                            jedis.hset(RedisPrefix.GOOD_LOANS_INFO + i, "endTime", Long.toString(endTime));
                            //存入MySQL
                            LoansGood loansGood = loansGoodService.getBaseMapper().selectById(i);
                            loansGood.setEndTime(new Date(endTime));
                            loansGood.setStartTime(new Date(startTime));
                            loansGood.setRepeatTimes(repeatTimes);
                            loansGood.setStatus(0);
                            loansGoodService.getBaseMapper().updateById(loansGood);
                        } else {
                            jedis.del(RedisPrefix.GOOD_LOANS_INFO + i);
                            LoansGood loansGood = loansGoodService.getBaseMapper().selectById(i);
                            loansGood.setStatus(2);
                            loansGoodService.getBaseMapper().updateById(loansGood);
                        }
                    }
                }
            }
        }
        jedis.close();
        isRunning.put("3","ended");
        System.out.println("商品结束检查结束[线程运行于:"+Thread.currentThread().getName()+"#"+Thread.currentThread().getId()+"]");
    }


    @Scheduled(cron = "0 */1 * * * ?")
    @Async("dataProcessExecutor")
    public void deleteDepositAndLoans() {
        if("running".equals(isRunning.get("4")))return;
        isRunning.put("4","running");
        System.out.println("订单过期检查开始[线程运行于:"+Thread.currentThread().getName()+"#"+Thread.currentThread().getId()+"]");
        Jedis jedis = getJedis();
        assert jedis != null;
        {
            Map<String, String> map = jedis.hgetAll(RedisPrefix.ORDER_LOANS);
            for (String key : map.keySet()) {
                OrderInfo orderInfo = JSON.parseObject(map.get(key), OrderInfo.class);
                long expireTime = orderInfo.getCreateTime().getTime() + 900000;
                long time = new Date().getTime();
                if (!orderInfo.getPaid() && time > expireTime) {
                    if (goodOnSaleService.rollBackOrder(orderInfo))
                        jedis.hdel(RedisPrefix.ORDER_LOANS, key);
                }
            }
        }
        {
            Map<String, String> map = jedis.hgetAll(RedisPrefix.ORDER_DEPOSIT);
            for (String key : map.keySet()) {
                OrderInfo orderInfo = JSON.parseObject(map.get(key), OrderInfo.class);
                long expireTime = orderInfo.getCreateTime().getTime() + 900000;
                long time = new Date().getTime();
                if (!orderInfo.getPaid() && time > expireTime) {
                    if (goodOnSaleService.rollBackOrder(orderInfo))
                        jedis.hdel(RedisPrefix.ORDER_DEPOSIT, key);
                }
            }
        }
        jedis.close();
        isRunning.put("4","ended");
        System.out.println("订单过期检查结束[线程运行于:"+Thread.currentThread().getName()+"#"+Thread.currentThread().getId()+"]");
    }
}
