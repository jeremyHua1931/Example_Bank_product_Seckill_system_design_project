package com.second_kill.entity.dashboard;


import lombok.Data;

@Data
public class GoodRank {
    private Integer id;
    private String name;
    private Integer number;
}
