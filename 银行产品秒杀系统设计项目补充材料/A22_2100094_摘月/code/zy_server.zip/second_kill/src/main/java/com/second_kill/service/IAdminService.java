package com.second_kill.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.second_kill.entity.Admin;

public interface IAdminService extends IService<Admin> {
    /**
     * 添加管理员
     *
     * @param admin
     */
    Admin addAdmin(Admin admin) throws Exception;

    /**
     * 登录
     *
     * @param pOrU     手机号或者用户名
     * @param password
     */
    Admin login(String pOrU, String password) throws Exception;

    /**
     * 删除管理员id
     *
     * @param id 管理员id
     */
    void deleteAdmin(Integer id);

    /**
     * 获取管理员信息
     *
     * @param id 管理员id
     * @return
     */
    Admin getInfo(Integer id);

    /**
     * 获取不含密码的管理页对象
     *
     * @param id 管理页ID
     * @return
     */
    Admin getInfoNoPwd(Integer id);

    /**
     * 更新管理员信息
     *
     * @param id
     * @param username
     * @param avatar
     */
    void updateInfo(Integer id, String username, String avatar, String password, String name, String phone) throws Exception;

    void deleteClient(Integer id);
}
