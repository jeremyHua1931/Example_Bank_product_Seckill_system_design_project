package com.second_kill.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.second_kill.entity.LoansFavor;

import java.util.List;

public interface ILoansFavorService extends IService<LoansFavor> {
    List<LoansFavor> getByUGId(Integer goodId, Integer userId);
}
