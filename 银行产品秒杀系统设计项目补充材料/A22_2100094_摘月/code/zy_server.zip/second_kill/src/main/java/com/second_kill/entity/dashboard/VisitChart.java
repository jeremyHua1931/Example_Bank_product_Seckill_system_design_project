package com.second_kill.entity.dashboard;

import lombok.Data;

@Data
public class VisitChart {
    private Integer number;
    private String date;
}
