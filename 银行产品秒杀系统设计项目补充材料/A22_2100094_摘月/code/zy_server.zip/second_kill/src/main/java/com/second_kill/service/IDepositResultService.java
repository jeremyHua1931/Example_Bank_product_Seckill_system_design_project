package com.second_kill.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.second_kill.entity.DepositResult;

import java.util.List;

public interface IDepositResultService extends IService<DepositResult> {
    /**
     * 获取存款初筛结果
     *
     * @param goodId
     * @param page
     * @param size
     * @return
     */
    List<DepositResult> depositFilterResult(Integer goodId, Integer page, Integer size);
}
